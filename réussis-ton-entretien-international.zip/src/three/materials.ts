import * as THREE from 'three';
import type { InterviewMode } from '../types/interview';
import type { ProceduralTextureSet } from './proceduralTextures';

export interface StudioMaterialLibrary {
  jacket: THREE.MeshPhysicalMaterial;
  shirt: THREE.MeshStandardMaterial;
  accentCloth: THREE.MeshPhysicalMaterial;
  skin: THREE.MeshPhysicalMaterial;
  lips: THREE.MeshStandardMaterial;
  hair: THREE.MeshStandardMaterial;
  sclera: THREE.MeshStandardMaterial;
  iris: THREE.MeshStandardMaterial;
  pupil: THREE.MeshStandardMaterial;
  mouthInterior: THREE.MeshStandardMaterial;
  brushedAluminum: THREE.MeshPhysicalMaterial;
  darkSteel: THREE.MeshStandardMaterial;
  walnutDesk: THREE.MeshStandardMaterial;
  wallSlat: THREE.MeshStandardMaterial;
  wallBackdrop: THREE.MeshStandardMaterial;
  floor: THREE.MeshStandardMaterial;
  notebookCover: THREE.MeshStandardMaterial;
  paper: THREE.MeshStandardMaterial;
  ceramicCup: THREE.MeshPhysicalMaterial;
  glassPanel: THREE.MeshPhysicalMaterial;
  ledAccent: THREE.MeshStandardMaterial;
  contactShadowMat: THREE.MeshBasicMaterial;
  dispose: () => void;
}

export function createStudioMaterials(
  textures: ProceduralTextureSet,
  mode: InterviewMode,
  isSoftwareGl: boolean
): StudioMaterialLibrary {
  const isRecruiter = mode === 'recruiter';

  const jacket = new THREE.MeshPhysicalMaterial({
    color: isRecruiter ? 0x262b34 : 0x1b2d4b,
    roughness: 0.85,
    metalness: 0.04,
    sheen: 0.45,
    sheenRoughness: 0.72,
    sheenColor: new THREE.Color(isRecruiter ? 0x4b5563 : 0x3b5998),
    bumpMap: textures.fabricBump,
    bumpScale: 0.004,
  });

  const shirt = new THREE.MeshStandardMaterial({
    color: isRecruiter ? 0xf4f6f9 : 0x475569,
    roughness: 0.78,
    metalness: 0.02,
    bumpMap: textures.fabricBump,
    bumpScale: 0.002,
  });

  const accentCloth = new THREE.MeshPhysicalMaterial({
    color: isRecruiter ? 0x1d3b72 : 0x2563eb,
    roughness: 0.65,
    metalness: 0.05,
    sheen: 0.6,
  });

  const skin = new THREE.MeshPhysicalMaterial({
    color: 0xdca582,
    roughness: 0.56,
    metalness: 0.0,
    clearcoat: 0.08,
    clearcoatRoughness: 0.65,
  });

  const lips = new THREE.MeshStandardMaterial({
    color: 0xb7715c,
    roughness: 0.48,
    metalness: 0.0,
  });

  const hair = new THREE.MeshStandardMaterial({
    color: isRecruiter ? 0x1e1a18 : 0x2c2724,
    roughness: 0.74,
    metalness: 0.06,
  });

  const sclera = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.22,
    metalness: 0.0,
  });

  const iris = new THREE.MeshStandardMaterial({
    color: isRecruiter ? 0x3a2618 : 0x38586f,
    roughness: 0.18,
    metalness: 0.05,
  });

  const pupil = new THREE.MeshStandardMaterial({
    color: 0x090b10,
    roughness: 0.12,
    metalness: 0.0,
  });

  const mouthInterior = new THREE.MeshStandardMaterial({
    color: 0x4b1d1d,
    roughness: 0.85,
    metalness: 0.0,
  });

  const brushedAluminum = new THREE.MeshPhysicalMaterial({
    color: 0xd4dbe4,
    metalness: 0.92,
    roughness: 0.22,
    anisotropy: 0.8,
  });

  const darkSteel = new THREE.MeshStandardMaterial({
    color: 0x1e2430,
    metalness: 0.82,
    roughness: 0.34,
  });

  const walnutDesk = new THREE.MeshStandardMaterial({
    map: textures.walnutAlbedo,
    bumpMap: textures.walnutBump,
    bumpScale: 0.006,
    roughness: 0.42,
    metalness: 0.06,
  });

  const wallSlat = new THREE.MeshStandardMaterial({
    map: textures.walnutAlbedo,
    roughness: 0.62,
    metalness: 0.04,
  });

  const wallBackdrop = new THREE.MeshStandardMaterial({
    color: 0x131926,
    roughness: 0.92,
    metalness: 0.02,
  });

  const floor = new THREE.MeshStandardMaterial({
    map: textures.floorAlbedo,
    roughness: 0.68,
    metalness: 0.12,
  });

  const notebookCover = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.72,
    metalness: 0.05,
  });

  const paper = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.88,
    metalness: 0.0,
  });

  const ceramicCup = new THREE.MeshPhysicalMaterial({
    color: 0xe2e8f0,
    roughness: 0.16,
    metalness: 0.02,
    clearcoat: 0.85,
    clearcoatRoughness: 0.1,
  });

  const glassPanel = new THREE.MeshPhysicalMaterial({
    color: 0xdbeafe,
    roughness: 0.08,
    metalness: 0.0,
    transmission: isSoftwareGl ? 0 : 0.82,
    transparent: true,
    opacity: isSoftwareGl ? 0.24 : 1,
    ior: 1.5,
    thickness: 0.12,
    depthWrite: false,
  });

  const ledAccent = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: 0x38bdf8,
    emissiveIntensity: 1.35,
    roughness: 0.25,
  });

  const contactShadowMat = new THREE.MeshBasicMaterial({
    map: textures.contactShadow,
    transparent: true,
    depthWrite: false,
    opacity: 0.52,
  });

  const all: THREE.Material[] = [
    jacket,
    shirt,
    accentCloth,
    skin,
    lips,
    hair,
    sclera,
    iris,
    pupil,
    mouthInterior,
    brushedAluminum,
    darkSteel,
    walnutDesk,
    wallSlat,
    wallBackdrop,
    floor,
    notebookCover,
    paper,
    ceramicCup,
    glassPanel,
    ledAccent,
    contactShadowMat,
  ];

  return {
    jacket,
    shirt,
    accentCloth,
    skin,
    lips,
    hair,
    sclera,
    iris,
    pupil,
    mouthInterior,
    brushedAluminum,
    darkSteel,
    walnutDesk,
    wallSlat,
    wallBackdrop,
    floor,
    notebookCover,
    paper,
    ceramicCup,
    glassPanel,
    ledAccent,
    contactShadowMat,
    dispose: () => {
      all.forEach((m) => m.dispose());
    },
  };
}
