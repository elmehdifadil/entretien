import * as THREE from 'three';
import type { StudioMaterialLibrary } from './materials';

export interface InterviewerRigHandle {
  root: THREE.Group;
  torsoGroup: THREE.Group;
  headPivot: THREE.Group;
  jawPivot: THREE.Group;
  leftEyelid: THREE.Mesh;
  rightEyelid: THREE.Mesh;
  leftIrisGroup: THREE.Group;
  rightIrisGroup: THREE.Group;
  micLed: THREE.Mesh;
  dispose: () => void;
}

export function buildExecutiveStudioAndAvatar(
  materials: StudioMaterialLibrary
): InterviewerRigHandle {
  const geometries: THREE.BufferGeometry[] = [];
  const track = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };

  const root = new THREE.Group();

  // ---------------------------------------------------------------------------
  // 1. Studio Floor & Architectural Acoustic Slat Wall (InstancedMesh > 20 slats)
  // ---------------------------------------------------------------------------
  const floorGeo = track(new THREE.PlaneGeometry(18, 18));
  floorGeo.rotateX(-Math.PI / 2);
  const floorMesh = new THREE.Mesh(floorGeo, materials.floor);
  floorMesh.position.y = 0;
  floorMesh.receiveShadow = true;
  root.add(floorMesh);

  const wallGeo = track(new THREE.BoxGeometry(10, 4.4, 0.14));
  const backWall = new THREE.Mesh(wallGeo, materials.wallBackdrop);
  backWall.position.set(0, 2.2, -2.05);
  backWall.receiveShadow = true;
  root.add(backWall);

  // Instanced acoustic walnut slats (36 slats)
  const slatCount = 36;
  const slatGeo = track(new THREE.BoxGeometry(0.075, 4.1, 0.055));
  const slatInstanced = new THREE.InstancedMesh(slatGeo, materials.wallSlat, slatCount);
  slatInstanced.castShadow = true;
  slatInstanced.receiveShadow = true;
  const dummy = new THREE.Object3D();
  const slatColor = new THREE.Color();
  for (let i = 0; i < slatCount; i++) {
    const x = -4.2 + i * 0.24;
    dummy.position.set(x, 2.05, -1.94);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    slatInstanced.setMatrixAt(i, dummy.matrix);
    const shade = 0.86 + ((i * 37) % 10) * 0.025;
    slatColor.setRGB(shade, shade * 0.96, shade * 0.92);
    slatInstanced.setColorAt(i, slatColor);
  }
  slatInstanced.instanceMatrix.needsUpdate = true;
  if (slatInstanced.instanceColor) slatInstanced.instanceColor.needsUpdate = true;
  slatInstanced.computeBoundingSphere();
  root.add(slatInstanced);

  // Subtle architectural glass partition on left studio wing
  const glassGeo = track(new THREE.BoxGeometry(0.03, 3.6, 2.8));
  const glassWall = new THREE.Mesh(glassGeo, materials.glassPanel);
  glassWall.position.set(-2.9, 1.8, -0.6);
  glassWall.renderOrder = 4;
  root.add(glassWall);

  const mullionGeo = track(new THREE.BoxGeometry(0.06, 3.6, 0.06));
  const mullion = new THREE.Mesh(mullionGeo, materials.darkSteel);
  mullion.position.set(-2.9, 1.8, 0.8);
  mullion.castShadow = true;
  root.add(mullion);

  // ---------------------------------------------------------------------------
  // 2. Executive Desk (Composite Multi-Part Group, Bottom-Center Pivoted at y=0)
  // ---------------------------------------------------------------------------
  const deskGroup = new THREE.Group();
  const deskHeight = 0.76;

  // Beveled desktop via ExtrudeGeometry
  const deskShape = new THREE.Shape();
  deskShape.moveTo(-1.15, -0.45);
  deskShape.lineTo(1.15, -0.45);
  deskShape.lineTo(1.15, 0.45);
  deskShape.lineTo(-1.15, 0.45);
  deskShape.closePath();

  const deskTopGeo = track(
    new THREE.ExtrudeGeometry(deskShape, {
      depth: 0.045,
      bevelEnabled: true,
      bevelThickness: 0.012,
      bevelSize: 0.015,
      bevelSegments: 3,
    })
  );
  deskTopGeo.rotateX(Math.PI / 2);
  deskTopGeo.computeTangents();
  const deskTop = new THREE.Mesh(deskTopGeo, materials.walnutDesk);
  deskTop.position.set(0, deskHeight, 0.32);
  deskTop.castShadow = true;
  deskTop.receiveShadow = true;
  deskGroup.add(deskTop);

  // Four brushed aluminum tapered legs flush with y=0
  const legGeo = track(new THREE.CylinderGeometry(0.026, 0.02, deskHeight - 0.04, 16));
  const legPositions: Array<[number, number]> = [
    [-1.02, -0.04],
    [1.02, -0.04],
    [-1.02, 0.68],
    [1.02, 0.68],
  ];
  for (const [lx, lz] of legPositions) {
    const leg = new THREE.Mesh(legGeo, materials.brushedAluminum);
    leg.position.set(lx, (deskHeight - 0.04) / 2, lz);
    leg.castShadow = true;
    deskGroup.add(leg);
  }

  // Steel modesty panel
  const modestyGeo = track(new THREE.BoxGeometry(2.0, 0.34, 0.02));
  const modesty = new THREE.Mesh(modestyGeo, materials.darkSteel);
  modesty.position.set(0, 0.52, 0.68);
  modesty.castShadow = true;
  deskGroup.add(modesty);

  // Desk radial contact shadow on floor (offset y=0.005 to prevent Z-fighting)
  const deskShadowGeo = track(new THREE.PlaneGeometry(3.2, 1.8));
  deskShadowGeo.rotateX(-Math.PI / 2);
  const deskShadow = new THREE.Mesh(deskShadowGeo, materials.contactShadowMat);
  deskShadow.position.set(0, 0.005, 0.25);
  deskGroup.add(deskShadow);

  root.add(deskGroup);

  // ---------------------------------------------------------------------------
  // 3. Desk Props (Composite Condenser Microphone, Notebook+Pen, Espresso Cup)
  // ---------------------------------------------------------------------------
  const deskSurfaceY = deskHeight + 0.012;

  // 3a. Composite Studio Microphone (Base + Boom + Shock Ring + Lathe Capsule)
  const micGroup = new THREE.Group();
  micGroup.position.set(-0.48, deskSurfaceY, 0.26);

  const micBaseGeo = track(new THREE.CylinderGeometry(0.075, 0.085, 0.018, 24));
  const micBase = new THREE.Mesh(micBaseGeo, materials.darkSteel);
  micBase.position.y = 0.009;
  micBase.castShadow = true;
  micGroup.add(micBase);

  const micStemCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0.018, 0),
    new THREE.Vector3(0, 0.14, 0.02),
    new THREE.Vector3(0.07, 0.23, 0.05),
  ]);
  const micStemGeo = track(new THREE.TubeGeometry(micStemCurve, 20, 0.01, 10, false));
  const micStem = new THREE.Mesh(micStemGeo, materials.brushedAluminum);
  micStem.castShadow = true;
  micGroup.add(micStem);

  const micCapsulePoints = [
    new THREE.Vector2(0, 0),
    new THREE.Vector2(0.022, 0.008),
    new THREE.Vector2(0.024, 0.065),
    new THREE.Vector2(0.018, 0.09),
    new THREE.Vector2(0, 0.098),
  ];
  const micCapsuleGeo = track(new THREE.LatheGeometry(micCapsulePoints, 20));
  const micCapsule = new THREE.Mesh(micCapsuleGeo, materials.brushedAluminum);
  micCapsule.position.set(0.075, 0.225, 0.055);
  micCapsule.rotation.set(0.25, 0, -0.35);
  micCapsule.castShadow = true;
  micGroup.add(micCapsule);

  const micLedGeo = track(new THREE.TorusGeometry(0.0245, 0.0025, 8, 24));
  const micLed = new THREE.Mesh(micLedGeo, materials.ledAccent);
  micLed.position.set(0.073, 0.24, 0.052);
  micLed.rotation.set(Math.PI / 2 + 0.25, -0.35, 0);
  micGroup.add(micLed);

  root.add(micGroup);

  // 3b. Executive Notebook + Brushed Pen
  const notebookGroup = new THREE.Group();
  notebookGroup.position.set(0.42, deskSurfaceY, 0.28);
  notebookGroup.rotation.y = -0.18;

  const coverGeo = track(new THREE.BoxGeometry(0.24, 0.012, 0.31));
  const cover = new THREE.Mesh(coverGeo, materials.notebookCover);
  cover.position.y = 0.006;
  cover.castShadow = true;
  notebookGroup.add(cover);

  const pagesGeo = track(new THREE.BoxGeometry(0.22, 0.008, 0.29));
  const pages = new THREE.Mesh(pagesGeo, materials.paper);
  pages.position.y = 0.014;
  notebookGroup.add(pages);

  const penGeo = track(new THREE.CylinderGeometry(0.005, 0.004, 0.16, 12));
  penGeo.rotateZ(Math.PI / 2);
  const pen = new THREE.Mesh(penGeo, materials.brushedAluminum);
  pen.position.set(0.02, 0.023, 0.03);
  pen.rotation.y = 0.45;
  pen.castShadow = true;
  notebookGroup.add(pen);

  root.add(notebookGroup);

  // 3c. Ceramic Espresso Cup (LatheGeometry)
  const cupPoints = [
    new THREE.Vector2(0, 0),
    new THREE.Vector2(0.032, 0),
    new THREE.Vector2(0.042, 0.075),
    new THREE.Vector2(0.038, 0.078),
    new THREE.Vector2(0.028, 0.01),
    new THREE.Vector2(0, 0.01),
  ];
  const cupGeo = track(new THREE.LatheGeometry(cupPoints, 24));
  const cup = new THREE.Mesh(cupGeo, materials.ceramicCup);
  cup.position.set(0.66, deskSurfaceY, 0.14);
  cup.castShadow = true;
  root.add(cup);

  // ---------------------------------------------------------------------------
  // 4. Composite 3D Executive Interlocutor Avatar (12+ Articulated Parts)
  // ---------------------------------------------------------------------------
  const avatarGroup = new THREE.Group();
  avatarGroup.position.set(0, 0, -0.22);

  // Chair backrest behind avatar
  const chairBackGeo = track(new THREE.BoxGeometry(0.5, 0.68, 0.06));
  const chairBack = new THREE.Mesh(chairBackGeo, materials.darkSteel);
  chairBack.position.set(0, 0.88, -0.24);
  chairBack.castShadow = true;
  avatarGroup.add(chairBack);

  // Torso Pivot (sits flush above seat height)
  const torsoGroup = new THREE.Group();
  torsoGroup.position.set(0, 0.64, 0);
  avatarGroup.add(torsoGroup);

  // Sculpted Jacket Torso (ExtrudeGeometry with smooth bevels)
  const torsoShape = new THREE.Shape();
  torsoShape.moveTo(-0.22, 0);
  torsoShape.lineTo(0.22, 0);
  torsoShape.quadraticCurveTo(0.26, 0.36, 0.21, 0.48);
  torsoShape.lineTo(0.08, 0.52);
  torsoShape.lineTo(-0.08, 0.52);
  torsoShape.lineTo(-0.21, 0.48);
  torsoShape.quadraticCurveTo(-0.26, 0.36, -0.22, 0);

  const torsoGeo = track(
    new THREE.ExtrudeGeometry(torsoShape, {
      depth: 0.2,
      bevelEnabled: true,
      bevelThickness: 0.035,
      bevelSize: 0.028,
      bevelSegments: 4,
    })
  );
  torsoGeo.translate(0, 0, -0.1);
  torsoGeo.computeTangents();
  const torsoMesh = new THREE.Mesh(torsoGeo, materials.jacket);
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  torsoGroup.add(torsoMesh);

  // Shirt V-insert + collar
  const shirtGeo = track(new THREE.ConeGeometry(0.11, 0.28, 4));
  shirtGeo.rotateX(Math.PI);
  shirtGeo.scale(1.1, 1, 0.35);
  const shirtChest = new THREE.Mesh(shirtGeo, materials.shirt);
  shirtChest.position.set(0, 0.39, 0.115);
  torsoGroup.add(shirtChest);

  // Tailored Lapels (left + right beveled accents)
  const lapelShape = new THREE.Shape();
  lapelShape.moveTo(0, 0);
  lapelShape.lineTo(0.055, 0.24);
  lapelShape.lineTo(0.01, 0.26);
  lapelShape.lineTo(-0.02, 0.04);
  lapelShape.closePath();
  const lapelGeo = track(
    new THREE.ExtrudeGeometry(lapelShape, {
      depth: 0.018,
      bevelEnabled: true,
      bevelThickness: 0.005,
      bevelSize: 0.005,
      bevelSegments: 2,
    })
  );

  const leftLapel = new THREE.Mesh(lapelGeo, materials.jacket);
  leftLapel.position.set(-0.03, 0.26, 0.125);
  leftLapel.rotation.z = 0.22;
  torsoGroup.add(leftLapel);

  const rightLapel = new THREE.Mesh(lapelGeo, materials.jacket);
  rightLapel.position.set(0.03, 0.26, 0.125);
  rightLapel.scale.x = -1;
  rightLapel.rotation.z = -0.22;
  torsoGroup.add(rightLapel);

  // Pocket square + metallic lapel pin accent
  const pocketSquareGeo = track(new THREE.BoxGeometry(0.065, 0.028, 0.012));
  const pocketSquare = new THREE.Mesh(pocketSquareGeo, materials.accentCloth);
  pocketSquare.position.set(0.125, 0.34, 0.132);
  pocketSquare.rotation.z = -0.12;
  torsoGroup.add(pocketSquare);

  const pinGeo = track(new THREE.CylinderGeometry(0.009, 0.009, 0.006, 16));
  pinGeo.rotateX(Math.PI / 2);
  const lapelPin = new THREE.Mesh(pinGeo, materials.brushedAluminum);
  lapelPin.position.set(-0.085, 0.42, 0.148);
  torsoGroup.add(lapelPin);

  // Shoulders & Forearms resting toward desk
  const shoulderGeo = track(new THREE.CapsuleGeometry(0.075, 0.22, 8, 16));
  const leftArm = new THREE.Mesh(shoulderGeo, materials.jacket);
  leftArm.position.set(-0.245, 0.34, 0.06);
  leftArm.rotation.set(-0.55, 0, 0.24);
  leftArm.castShadow = true;
  torsoGroup.add(leftArm);

  const rightArm = new THREE.Mesh(shoulderGeo, materials.jacket);
  rightArm.position.set(0.245, 0.34, 0.06);
  rightArm.rotation.set(-0.55, 0, -0.24);
  rightArm.castShadow = true;
  torsoGroup.add(rightArm);

  // Neck + Collar Ring
  const neckGeo = track(new THREE.CylinderGeometry(0.056, 0.068, 0.14, 20));
  const neck = new THREE.Mesh(neckGeo, materials.skin);
  neck.position.set(0, 0.56, 0.01);
  neck.castShadow = true;
  torsoGroup.add(neck);

  // Articulated Head Pivot
  const headPivot = new THREE.Group();
  headPivot.position.set(0, 0.64, 0.02);
  torsoGroup.add(headPivot);

  // Cranium + Cheek Profile (LatheGeometry sculpted human head profile)
  const headPoints = [
    new THREE.Vector2(0.0, -0.02),
    new THREE.Vector2(0.068, 0.01),
    new THREE.Vector2(0.095, 0.06),
    new THREE.Vector2(0.104, 0.13),
    new THREE.Vector2(0.098, 0.2),
    new THREE.Vector2(0.072, 0.245),
    new THREE.Vector2(0.0, 0.262),
  ];
  const craniumGeo = track(new THREE.LatheGeometry(headPoints, 28));
  craniumGeo.scale(0.92, 1, 1.04);
  const cranium = new THREE.Mesh(craniumGeo, materials.skin);
  cranium.castShadow = true;
  headPivot.add(cranium);

  // Hair Crown & Side Contour
  const hairCrownGeo = track(new THREE.SphereGeometry(0.107, 24, 18, 0, Math.PI * 2, 0, Math.PI * 0.54));
  hairCrownGeo.scale(0.94, 0.88, 1.07);
  const hairCrown = new THREE.Mesh(hairCrownGeo, materials.hair);
  hairCrown.position.set(0, 0.175, -0.008);
  hairCrown.rotation.x = -0.18;
  hairCrown.castShadow = true;
  headPivot.add(hairCrown);

  // Sculpted Nose Bridge
  const noseGeo = track(new THREE.ConeGeometry(0.016, 0.05, 8));
  const nose = new THREE.Mesh(noseGeo, materials.skin);
  nose.position.set(0, 0.108, 0.108);
  nose.rotation.x = 0.35;
  headPivot.add(nose);

  // Ears (left + right)
  const earGeo = track(new THREE.SphereGeometry(0.022, 12, 12));
  earGeo.scale(0.45, 1.15, 0.7);
  const leftEar = new THREE.Mesh(earGeo, materials.skin);
  leftEar.position.set(-0.096, 0.115, -0.008);
  headPivot.add(leftEar);
  const rightEar = new THREE.Mesh(earGeo, materials.skin);
  rightEar.position.set(0.096, 0.115, -0.008);
  headPivot.add(rightEar);

  // Eyes (Sclera + IrisGroup + Pupil + Articulated Eyelids)
  const eyeSocketGeo = track(new THREE.SphereGeometry(0.0155, 16, 16));
  const irisGeo = track(new THREE.CylinderGeometry(0.008, 0.008, 0.003, 16));
  irisGeo.rotateX(Math.PI / 2);
  const pupilGeo = track(new THREE.CylinderGeometry(0.0042, 0.0042, 0.0035, 12));
  pupilGeo.rotateX(Math.PI / 2);
  const eyelidGeo = track(new THREE.SphereGeometry(0.0165, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.52));

  const createEye = (xOffset: number) => {
    const eyeGroup = new THREE.Group();
    eyeGroup.position.set(xOffset, 0.138, 0.092);

    const scleraMesh = new THREE.Mesh(eyeSocketGeo, materials.sclera);
    eyeGroup.add(scleraMesh);

    const irisGroup = new THREE.Group();
    const irisMesh = new THREE.Mesh(irisGeo, materials.iris);
    irisMesh.position.z = 0.0145;
    const pupilMesh = new THREE.Mesh(pupilGeo, materials.pupil);
    pupilMesh.position.z = 0.0155;
    irisGroup.add(irisMesh, pupilMesh);
    eyeGroup.add(irisGroup);

    const eyelid = new THREE.Mesh(eyelidGeo, materials.skin);
    eyelid.rotation.x = -0.75; // open pose
    eyeGroup.add(eyelid);

    headPivot.add(eyeGroup);
    return { irisGroup, eyelid };
  };

  const leftEye = createEye(-0.036);
  const rightEye = createEye(0.036);

  // Eyebrows (expressive tiltable arches)
  const browGeo = track(new THREE.BoxGeometry(0.034, 0.007, 0.008));
  const leftBrow = new THREE.Mesh(browGeo, materials.hair);
  leftBrow.position.set(-0.036, 0.164, 0.096);
  leftBrow.rotation.z = 0.08;
  headPivot.add(leftBrow);

  const rightBrow = new THREE.Mesh(browGeo, materials.hair);
  rightBrow.position.set(0.036, 0.164, 0.096);
  rightBrow.rotation.z = -0.08;
  headPivot.add(rightBrow);

  // Mouth cavity + Upper Lip + Articulated Jaw Pivot (voice-reactive lip sync)
  const mouthCavityGeo = track(new THREE.BoxGeometry(0.044, 0.018, 0.018));
  const mouthCavity = new THREE.Mesh(mouthCavityGeo, materials.mouthInterior);
  mouthCavity.position.set(0, 0.056, 0.089);
  headPivot.add(mouthCavity);

  const upperLipGeo = track(new THREE.CapsuleGeometry(0.0055, 0.032, 6, 12));
  upperLipGeo.rotateZ(Math.PI / 2);
  const upperLip = new THREE.Mesh(upperLipGeo, materials.lips);
  upperLip.position.set(0, 0.064, 0.097);
  headPivot.add(upperLip);

  const jawPivot = new THREE.Group();
  jawPivot.position.set(0, 0.072, 0.015);
  headPivot.add(jawPivot);

  const chinGeo = track(new THREE.CapsuleGeometry(0.048, 0.028, 8, 16));
  chinGeo.scale(1.05, 0.85, 0.92);
  const chin = new THREE.Mesh(chinGeo, materials.skin);
  chin.position.set(0, -0.038, 0.045);
  chin.castShadow = true;
  jawPivot.add(chin);

  const lowerLipGeo = track(new THREE.CapsuleGeometry(0.0055, 0.03, 6, 12));
  lowerLipGeo.rotateZ(Math.PI / 2);
  const lowerLip = new THREE.Mesh(lowerLipGeo, materials.lips);
  lowerLip.position.set(0, -0.019, 0.081);
  jawPivot.add(lowerLip);

  root.add(avatarGroup);

  return {
    root,
    torsoGroup,
    headPivot,
    jawPivot,
    leftEyelid: leftEye.eyelid,
    rightEyelid: rightEye.eyelid,
    leftIrisGroup: leftEye.irisGroup,
    rightIrisGroup: rightEye.irisGroup,
    micLed,
    dispose: () => {
      geometries.forEach((g) => g.dispose());
    },
  };
}
