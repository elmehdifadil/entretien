import * as THREE from 'three';

export interface ProceduralTextureSet {
  walnutAlbedo: THREE.CanvasTexture;
  walnutBump: THREE.CanvasTexture;
  fabricBump: THREE.CanvasTexture;
  floorAlbedo: THREE.CanvasTexture;
  contactShadow: THREE.CanvasTexture;
  dispose: () => void;
}

export function createProceduralTextures(maxAnisotropy: number): ProceduralTextureSet {
  // 1. Walnut Wood Albedo (SRGB)
  const woodCanvas = document.createElement('canvas');
  woodCanvas.width = 512;
  woodCanvas.height = 512;
  const wCtx = woodCanvas.getContext('2d')!;
  wCtx.fillStyle = '#4a3222';
  wCtx.fillRect(0, 0, 512, 512);

  for (let y = 0; y < 512; y++) {
    const wave = Math.sin(y * 0.045) * 14 + Math.sin(y * 0.14) * 5;
    const tone = Math.floor(62 + Math.sin((y + wave) * 0.18) * 14);
    wCtx.fillStyle = `rgb(${tone + 18}, ${Math.floor(tone * 0.72)}, ${Math.floor(tone * 0.48)})`;
    wCtx.fillRect(0, y, 512, 1);
  }
  // Subtle wood pores
  wCtx.fillStyle = 'rgba(22, 12, 6, 0.22)';
  for (let i = 0; i < 420; i++) {
    const x = (i * 73) % 512;
    const y = (i * 139) % 512;
    wCtx.fillRect(x, y, 18 + (i % 28), 1);
  }

  const walnutAlbedo = new THREE.CanvasTexture(woodCanvas);
  walnutAlbedo.colorSpace = THREE.SRGBColorSpace;
  walnutAlbedo.wrapS = THREE.RepeatWrapping;
  walnutAlbedo.wrapT = THREE.RepeatWrapping;
  walnutAlbedo.repeat.set(2, 1);
  walnutAlbedo.anisotropy = maxAnisotropy;

  // 2. Walnut Bump Map (Linear NoColorSpace)
  const woodBumpCanvas = document.createElement('canvas');
  woodBumpCanvas.width = 512;
  woodBumpCanvas.height = 512;
  const wbCtx = woodBumpCanvas.getContext('2d')!;
  wbCtx.fillStyle = '#808080';
  wbCtx.fillRect(0, 0, 512, 512);
  for (let y = 0; y < 512; y++) {
    const v = Math.floor(128 + Math.sin(y * 0.22) * 28);
    wbCtx.fillStyle = `rgb(${v},${v},${v})`;
    wbCtx.fillRect(0, y, 512, 1);
  }
  const walnutBump = new THREE.CanvasTexture(woodBumpCanvas);
  walnutBump.wrapS = THREE.RepeatWrapping;
  walnutBump.wrapT = THREE.RepeatWrapping;
  walnutBump.repeat.set(2, 1);
  walnutBump.anisotropy = maxAnisotropy;

  // 3. Tailored Suit Weave Bump Map (Linear NoColorSpace)
  const fabricCanvas = document.createElement('canvas');
  fabricCanvas.width = 256;
  fabricCanvas.height = 256;
  const fCtx = fabricCanvas.getContext('2d')!;
  fCtx.fillStyle = '#808080';
  fCtx.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 2) {
    for (let x = 0; x < 256; x += 2) {
      const weave = ((x + y) % 4 === 0 ? 152 : 108);
      fCtx.fillStyle = `rgb(${weave},${weave},${weave})`;
      fCtx.fillRect(x, y, 2, 2);
    }
  }
  const fabricBump = new THREE.CanvasTexture(fabricCanvas);
  fabricBump.wrapS = THREE.RepeatWrapping;
  fabricBump.wrapT = THREE.RepeatWrapping;
  fabricBump.repeat.set(14, 14);
  fabricBump.anisotropy = maxAnisotropy;

  // 4. Studio Floor Architectural Slate Grid (SRGB)
  const floorCanvas = document.createElement('canvas');
  floorCanvas.width = 512;
  floorCanvas.height = 512;
  const flCtx = floorCanvas.getContext('2d')!;
  flCtx.fillStyle = '#141b29';
  flCtx.fillRect(0, 0, 512, 512);
  flCtx.strokeStyle = 'rgba(148, 163, 184, 0.08)';
  flCtx.lineWidth = 2;
  flCtx.strokeRect(1, 1, 510, 510);
  flCtx.strokeStyle = 'rgba(148, 163, 184, 0.04)';
  flCtx.beginPath();
  flCtx.moveTo(256, 0);
  flCtx.lineTo(256, 512);
  flCtx.moveTo(0, 256);
  flCtx.lineTo(512, 256);
  flCtx.stroke();

  const floorAlbedo = new THREE.CanvasTexture(floorCanvas);
  floorAlbedo.colorSpace = THREE.SRGBColorSpace;
  floorAlbedo.wrapS = THREE.RepeatWrapping;
  floorAlbedo.wrapT = THREE.RepeatWrapping;
  floorAlbedo.repeat.set(12, 12);
  floorAlbedo.anisotropy = maxAnisotropy;

  // 5. Soft Radial Contact Shadow Texture
  const shadowCanvas = document.createElement('canvas');
  shadowCanvas.width = 256;
  shadowCanvas.height = 256;
  const sCtx = shadowCanvas.getContext('2d')!;
  const grad = sCtx.createRadialGradient(128, 128, 12, 128, 128, 124);
  grad.addColorStop(0, 'rgba(3, 7, 18, 0.72)');
  grad.addColorStop(0.55, 'rgba(3, 7, 18, 0.28)');
  grad.addColorStop(1, 'rgba(3, 7, 18, 0.0)');
  sCtx.fillStyle = grad;
  sCtx.fillRect(0, 0, 256, 256);

  const contactShadow = new THREE.CanvasTexture(shadowCanvas);
  contactShadow.colorSpace = THREE.SRGBColorSpace;

  return {
    walnutAlbedo,
    walnutBump,
    fabricBump,
    floorAlbedo,
    contactShadow,
    dispose: () => {
      walnutAlbedo.dispose();
      walnutBump.dispose();
      fabricBump.dispose();
      floorAlbedo.dispose();
      contactShadow.dispose();
    },
  };
}
