import React, { useEffect, useRef, useState } from 'react';
import {
  Box,
  Briefcase,
  CheckCircle2,
  Compass,
  Globe2,
  Headphones,
  Loader2,
  Mic,
  MicOff,
  Play,
  ShieldCheck,
  Sparkles,
  Volume2,
} from 'lucide-react';
import {
  LANGUAGE_OPTIONS,
  POPULAR_COUNTRIES,
  ROLE_PRESETS,
  type CulturalBrief,
  type ExperienceLevel,
  type InteractionChannel,
  type InterviewConfig,
  type InterviewFocus,
  type InterviewMode,
  type VisualStyle,
} from '../types/interview';
import { COACH_PORTRAIT_URL, RECRUITER_PORTRAIT_URL } from './InterlocutorStage';
import { startMicCapture, type MicCaptureController } from '../utils/audioEngine';

interface SetupWorkspaceProps {
  config: InterviewConfig;
  onChangeConfig: (next: InterviewConfig) => void;
  onStartInterview: () => void;
  onOpenStudio3D?: () => void;
}

export const SetupWorkspace: React.FC<SetupWorkspaceProps> = ({
  config,
  onChangeConfig,
  onStartInterview,
  onOpenStudio3D,
}) => {
  const [validationError, setValidationError] = useState<string | null>(null);
  const [brief, setBrief] = useState<CulturalBrief | null>(null);
  const [briefLoading, setBriefLoading] = useState(false);
  const [briefError, setBriefError] = useState<string | null>(null);

  // Quick mic test state
  const [micTesting, setMicTesting] = useState(false);
  const [micLevel, setMicLevel] = useState(0);
  const [micTestError, setMicTestError] = useState<string | null>(null);
  const micTestRef = useRef<MicCaptureController | null>(null);

  useEffect(() => {
    return () => {
      if (micTestRef.current) {
        micTestRef.current.stop();
        micTestRef.current = null;
      }
    };
  }, []);

  const update = <K extends keyof InterviewConfig>(key: K, value: InterviewConfig[K]) => {
    setValidationError(null);
    onChangeConfig({ ...config, [key]: value });
  };

  const handleToggleMicTest = async () => {
    if (micTesting) {
      micTestRef.current?.stop();
      micTestRef.current = null;
      setMicTesting(false);
      setMicLevel(0);
      return;
    }

    setMicTestError(null);
    try {
      const controller = await startMicCapture({
        onPcm40ms: () => {
          // test mode only measures input amplitude
        },
        onLevel: (lvl) => setMicLevel(lvl),
        shouldGate: () => false,
      });
      micTestRef.current = controller;
      setMicTesting(true);
    } catch {
      setMicTestError(
        "Impossible d'accéder au microphone. Vérifiez les permissions du navigateur ou choisissez le mode Texte + Voix."
      );
      setMicTesting(false);
    }
  };

  const handleGenerateBrief = async () => {
    if (!config.role.trim() || !config.country.trim()) {
      setBriefError('Renseignez d’abord le poste visé et le pays de destination.');
      return;
    }
    setBriefError(null);
    setBriefLoading(true);
    try {
      const res = await fetch('/api/interview/prepare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erreur lors de la préparation du brief.');
      }
      setBrief(data.brief as CulturalBrief);
    } catch (err) {
      setBriefError(err instanceof Error ? err.message : 'Impossible de générer le brief.');
    } finally {
      setBriefLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!config.role.trim() || !config.country.trim() || !config.language) {
      setValidationError(
        'Veuillez renseigner les trois champs requis : poste visé, pays de destination et langue.'
      );
      return;
    }
    if (micTestRef.current) {
      micTestRef.current.stop();
      micTestRef.current = null;
      setMicTesting(false);
    }
    onStartInterview();
  };

  const previewPortrait =
    config.mode === 'recruiter' ? RECRUITER_PORTRAIT_URL : COACH_PORTRAIT_URL;

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:py-10">
      {/* Focused Hero Lead */}
      <section className="mb-8 border-b border-slate-200 pb-7">
        <p className="text-xs font-medium text-blue-700">
          Simulation vocale &amp; évaluation structurée · Session de 8 minutes
        </p>
        <h1 className="font-display mt-2 max-w-3xl text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl [text-wrap:balance]">
          Préparez vos entretiens internationaux en conditions réelles
        </h1>
        <p className="mt-3 max-w-2xl text-base leading-relaxed text-slate-600">
          Choisissez votre mode — Recruteur exigeant ou Coach bienveillant — puis exercez-vous à
          l’oral ou par écrit avec un diagnostic détaillé sur 5 axes.
        </p>

        {/* Quick presets */}
        <div className="mt-5 flex flex-wrap items-center gap-2">
          <span className="text-xs font-medium text-slate-500 mr-1">Scénarios rapides :</span>
          {ROLE_PRESETS.map((preset) => (
            <button
              key={preset.role}
              type="button"
              onClick={() => {
                setValidationError(null);
                onChangeConfig({
                  ...config,
                  role: preset.role,
                  country: preset.country,
                  focus: preset.focus,
                  experienceLevel: preset.experienceLevel,
                });
              }}
              className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:border-blue-300 hover:bg-blue-50/50 hover:text-blue-800 transition-colors"
            >
              {preset.role} · {preset.country}
            </button>
          ))}
        </div>
      </section>

      {/* Main 2-column Studio Split */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-start">
        {/* Left: Configuration Form (7 cols) */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white p-6 sm:p-8"
        >
          {/* Mode Segmented Control */}
          <div>
            <label className="block text-sm font-semibold text-slate-900">
              Mode d’accompagnement
            </label>
            <div className="mt-2.5 grid grid-cols-1 gap-2 sm:grid-cols-2 rounded-xl bg-slate-100 p-1.5">
              {(
                [
                  {
                    id: 'recruiter' as InterviewMode,
                    title: 'Mode Recruteur',
                    desc: 'Entretien réaliste avec questions de relance',
                  },
                  {
                    id: 'coach' as InterviewMode,
                    title: 'Mode Coach',
                    desc: 'Feedback immédiat et conseils STAR à chaque tour',
                  },
                ] as const
              ).map((item) => {
                const active = config.mode === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => update('mode', item.id)}
                    className={`rounded-lg px-4 py-3 text-left transition-all ${
                      active
                        ? 'bg-white text-slate-900 shadow-sm ring-1 ring-slate-200'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <div className="text-sm font-semibold">{item.title}</div>
                    <div className="mt-0.5 text-xs text-slate-500">{item.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3 Required Fields (V5 validation rule) */}
          <div className="mt-7 grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label htmlFor="role-input" className="block text-sm font-semibold text-slate-900">
                Poste visé <span className="text-rose-600">*</span>
              </label>
              <div className="relative mt-1.5">
                <Briefcase
                  className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-slate-400"
                  aria-hidden="true"
                />
                <input
                  id="role-input"
                  type="text"
                  required
                  value={config.role}
                  onChange={(e) => update('role', e.target.value)}
                  placeholder="Ex : Chef de Projet Digital, Ingénieur Cloud, Contrôleur de Gestion..."
                  className="w-full rounded-lg border border-slate-300 bg-white py-2.5 pl-10 pr-3.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                />
              </div>
              <p className="mt-1 text-xs text-slate-500">
                Évitez de saisir des données personnelles sensibles (nom complet, téléphone, adresse).
              </p>
            </div>

            <div>
              <label htmlFor="country-input" className="block text-sm font-semibold text-slate-900">
                Pays de destination <span className="text-rose-600">*</span>
              </label>
              <div className="relative mt-1.5">
                <Globe2
                  className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-slate-400"
                  aria-hidden="true"
                />
                <input
                  id="country-input"
                  list="countries-datalist"
                  type="text"
                  required
                  value={config.country}
                  onChange={(e) => update('country', e.target.value)}
                  placeholder="Ex : Canada, France, Allemagne..."
                  className="w-full rounded-lg border border-slate-300 bg-white py-2.5 pl-10 pr-3.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                />
                <datalist id="countries-datalist">
                  {POPULAR_COUNTRIES.map((c) => (
                    <option key={c} value={c} />
                  ))}
                </datalist>
              </div>
            </div>

            <div>
              <label htmlFor="lang-select" className="block text-sm font-semibold text-slate-900">
                Langue de l’entretien <span className="text-rose-600">*</span>
              </label>
              <select
                id="lang-select"
                value={config.language}
                onChange={(e) => update('language', e.target.value as InterviewConfig['language'])}
                className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
              >
                {LANGUAGE_OPTIONS.map((lang) => (
                  <option key={lang.code} value={lang.code}>
                    {lang.label} — {lang.nativeLabel}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Experience & Focus */}
          <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="exp-select" className="block text-sm font-semibold text-slate-900">
                Niveau d’expérience
              </label>
              <select
                id="exp-select"
                value={config.experienceLevel}
                onChange={(e) =>
                  update('experienceLevel', e.target.value as ExperienceLevel)
                }
                className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
              >
                <option value="junior">Junior (0–2 ans)</option>
                <option value="mid">Confirmé (3–6 ans)</option>
                <option value="senior">Senior (7–12 ans)</option>
                <option value="executive">Lead / Direction (12+ ans)</option>
              </select>
            </div>

            <div>
              <label htmlFor="focus-select" className="block text-sm font-semibold text-slate-900">
                Axe prioritaire
              </label>
              <select
                id="focus-select"
                value={config.focus}
                onChange={(e) => update('focus', e.target.value as InterviewFocus)}
                className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
              >
                <option value="comprehensive">Entretien complet</option>
                <option value="behavioral_star">Comportemental (STAR)</option>
                <option value="technical_role">Expertise métier &amp; cas pratiques</option>
                <option value="cultural_negotiation">Codes culturels &amp; négociation</option>
              </select>
            </div>
          </div>

          {/* Optional Job Description */}
          <div className="mt-5">
            <label htmlFor="jd-textarea" className="block text-sm font-semibold text-slate-900">
              Offre d’emploi ou contexte spécifique <span className="font-normal text-slate-500">(facultatif)</span>
            </label>
            <textarea
              id="jd-textarea"
              rows={3}
              value={config.jobDescription}
              onChange={(e) => update('jobDescription', e.target.value)}
              placeholder="Collez quelques lignes de l’annonce ou précisez le secteur d’activité (banque, SaaS, industrie, santé)..."
              className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            />
          </div>

          {/* Audio, Visual & Anti-Echo Settings (V14) */}
          <div className="mt-6 border-t border-slate-200 pt-6 space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700">
                  Canal d’interaction
                </label>
                <div className="mt-1.5 flex rounded-lg bg-slate-100 p-1">
                  {(
                    [
                      { id: 'live_voice' as InteractionChannel, label: 'Voix en direct' },
                      { id: 'text_voice' as InteractionChannel, label: 'Texte + Voix' },
                    ] as const
                  ).map((ch) => (
                    <button
                      key={ch.id}
                      type="button"
                      onClick={() => update('channel', ch.id)}
                      className={`flex-1 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                        config.channel === ch.id
                          ? 'bg-white text-slate-900 shadow-sm'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {ch.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700">
                  Présentation visuelle
                </label>
                <select
                  value={config.visualStyle}
                  onChange={(e) => update('visualStyle', e.target.value as VisualStyle)}
                  className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-600 focus:outline-none"
                >
                  <option value="portrait">Portrait humain interactif</option>
                  <option value="avatar_3d">Avatar 3D Studio (Three.js)</option>
                  <option value="flow_video">Vidéo Flow (avec secours portrait)</option>
                  <option value="voice_only">Audio seul (sans image)</option>
                </select>
              </div>
            </div>

            {config.channel === 'live_voice' && (
              <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 space-y-3">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.antiEchoProtection}
                    onChange={(e) => update('antiEchoProtection', e.target.checked)}
                    className="mt-0.5 h-4 w-4 rounded border-slate-300 text-blue-700 focus:ring-blue-600"
                  />
                  <span className="text-xs leading-relaxed text-slate-700">
                    <span className="font-semibold text-slate-900 inline-flex items-center gap-1.5">
                      <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" aria-hidden="true" />
                      Protection anti-écho activée
                    </span>{' '}
                    — met automatiquement le microphone en pause pendant que l’IA parle pour éviter
                    les coupures et l’écho sur haut-parleurs.
                  </span>
                </label>

                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.allowInterruptions}
                    onChange={(e) => update('allowInterruptions', e.target.checked)}
                    className="mt-0.5 h-4 w-4 rounded border-slate-300 text-blue-700 focus:ring-blue-600"
                  />
                  <span className="text-xs leading-relaxed text-slate-700">
                    <span className="font-semibold text-slate-900 inline-flex items-center gap-1.5">
                      <Headphones className="h-3.5 w-3.5 text-blue-700" aria-hidden="true" />
                      Autoriser les interruptions pendant la parole (uniquement avec un casque)
                    </span>
                  </span>
                </label>

                {/* Live Microphone Pre-Check */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-200/80">
                  <button
                    type="button"
                    onClick={handleToggleMicTest}
                    className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-50 transition-colors"
                  >
                    {micTesting ? (
                      <>
                        <MicOff className="h-3.5 w-3.5 text-rose-600" aria-hidden="true" />
                        <span>Arrêter le test micro</span>
                      </>
                    ) : (
                      <>
                        <Mic className="h-3.5 w-3.5 text-blue-700" aria-hidden="true" />
                        <span>Tester mon microphone</span>
                      </>
                    )}
                  </button>

                  <div className="flex flex-1 items-center gap-2 min-w-[140px]">
                    <span className="text-[11px] text-slate-500">Niveau :</span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-200">
                      <div
                        className="h-full rounded-full bg-emerald-600 transition-all duration-75"
                        style={{ width: `${Math.round(micLevel * 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
                {micTestError && (
                  <p className="text-xs text-rose-700" role="alert">
                    {micTestError}
                  </p>
                )}
              </div>
            )}
          </div>

          {validationError && (
            <div
              role="alert"
              className="mt-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800"
            >
              {validationError}
            </div>
          )}

          <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
            <p className="text-xs text-slate-500">
              Les champs ne sont pas modifiables pendant l’appel · Vue visioconférence automatique
            </p>
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-blue-700 px-6 py-3 text-sm font-semibold text-white hover:bg-blue-800 active:scale-[0.99] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 min-h-[44px]"
            >
              <Play className="h-4 w-4 fill-current" aria-hidden="true" />
              <span>Commencer l’entretien</span>
            </button>
          </div>
        </form>

        {/* Right: Interlocutor Preview & AI Cultural Strategic Brief (5 cols) */}
        <aside className="lg:col-span-5 space-y-6">
          {/* Interlocutor Preview Card */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
            <div className="relative h-64 w-full overflow-hidden bg-slate-900">
              <img
                src={previewPortrait}
                alt={
                  config.mode === 'recruiter'
                    ? 'Portrait du recruteur international'
                    : 'Portrait du coach carrière'
                }
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover object-top"
              />
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent"
              />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-5 text-white">
                <div>
                  <p className="text-xs font-medium text-sky-300">
                    {config.mode === 'recruiter'
                      ? 'Interlocuteur · Recruteur masculin'
                      : 'Interlocuteur · Coach masculin'}
                  </p>
                  <p className="font-display mt-0.5 text-lg font-bold">
                    {config.mode === 'recruiter' ? 'Karim — Recruteur Senior' : 'Marc — Coach Exécutif'}
                  </p>
                  <p className="mt-1 flex items-center gap-1.5 text-xs text-slate-300">
                    <Volume2 className="h-3.5 w-3.5 text-sky-400" aria-hidden="true" />
                    <span>Voix studio Charon · Démarrage direct sans répétition</span>
                  </p>
                </div>
                {onOpenStudio3D && (
                  <button
                    type="button"
                    onClick={onOpenStudio3D}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-white/25 bg-slate-950/85 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-900 transition-colors whitespace-nowrap shrink-0"
                  >
                    <Box className="h-3.5 w-3.5 text-sky-400" aria-hidden="true" />
                    <span>Studio 3D</span>
                  </button>
                )}
              </div>
            </div>

            <div className="p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h2 className="font-display text-sm font-bold text-slate-900">
                    Brief stratégique du pays cible
                  </h2>
                  <p className="mt-0.5 text-xs text-slate-500">
                    Codes culturels &amp; questions attendues pour {config.country || 'votre pays'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleGenerateBrief}
                  disabled={briefLoading}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 disabled:opacity-60 transition-colors whitespace-nowrap shrink-0"
                >
                  {briefLoading ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                  ) : (
                    <Sparkles className="h-3.5 w-3.5 text-blue-700" aria-hidden="true" />
                  )}
                  <span>{brief ? 'Actualiser' : 'Préparer le brief'}</span>
                </button>
              </div>

              {briefError && (
                <p className="mt-3 text-xs text-rose-700" role="alert">
                  {briefError}
                </p>
              )}

              {!brief && !briefLoading && !briefError && (
                <div className="mt-4 rounded-xl border border-dashed border-slate-200 bg-slate-50/70 p-4 text-xs leading-relaxed text-slate-600">
                  <div className="flex items-center gap-2 font-semibold text-slate-800">
                    <Compass className="h-4 w-4 text-blue-700" aria-hidden="true" />
                    <span>Conseil avant de lancer l’appel</span>
                  </div>
                  <p className="mt-1.5">
                    Cliquez sur « Préparer le brief » pour obtenir les attentes culturelles des
                    recruteurs en {config.country || 'cible'} et 2 questions clés à poser en fin
                    d’entretien.
                  </p>
                </div>
              )}

              {briefLoading && (
                <div className="mt-4 space-y-2.5 animate-pulse">
                  <div className="h-3 w-3/4 rounded bg-slate-200" />
                  <div className="h-3 w-full rounded bg-slate-200" />
                  <div className="h-3 w-5/6 rounded bg-slate-200" />
                </div>
              )}

              {brief && !briefLoading && (
                <div className="mt-4 space-y-4 text-xs leading-relaxed text-slate-700">
                  <div className="rounded-lg bg-blue-50/70 p-3 text-slate-800">
                    <span className="font-semibold text-blue-900">60 premières secondes : </span>
                    {brief.openingTip}
                  </div>

                  <div>
                    <h3 className="font-semibold text-slate-900">Codes culturels ({config.country})</h3>
                    <ul className="mt-1.5 space-y-1.5">
                      {brief.culturalCodes.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle2
                            className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600"
                            aria-hidden="true"
                          />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-slate-900">Thèmes &amp; questions probables</h3>
                    <ul className="mt-1.5 list-disc pl-4 space-y-1 text-slate-600">
                      {brief.expectedThemes.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-slate-900">Questions à poser au recruteur</h3>
                    <ul className="mt-1.5 list-disc pl-4 space-y-1 text-slate-600">
                      {brief.smartQuestions.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
};
