import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Clock,
  Headphones,
  Loader2,
  MessageSquare,
  Mic,
  MicOff,
  PhoneOff,
  Send,
  ShieldCheck,
  Sparkles,
  Square,
} from 'lucide-react';
import {
  LANGUAGE_OPTIONS,
  SESSION_DURATION_SECONDS,
  type InterlocutorState,
  type InterviewConfig,
  type TranscriptEntry,
  type VisualStyle,
} from '../types/interview';
import {
  PcmPlaybackQueue,
  startMicCapture,
  type MicCaptureController,
} from '../utils/audioEngine';
import { formatDuration } from '../utils/storage';
import { InterlocutorStage } from './InterlocutorStage';

interface LiveCallViewProps {
  config: InterviewConfig;
  transcript: TranscriptEntry[];
  onTranscriptChange: React.Dispatch<React.SetStateAction<TranscriptEntry[]>>;
  onUpdateVisualStyle: (style: VisualStyle) => void;
  onElapsedChange?: (elapsedSeconds: number) => void;
  onFinishSession: (finalTranscript: TranscriptEntry[], elapsedSeconds: number) => void;
}

export const LiveCallView: React.FC<LiveCallViewProps> = ({
  config,
  transcript,
  onTranscriptChange,
  onUpdateVisualStyle,
  onElapsedChange,
  onFinishSession,
}) => {
  const [channel, setChannel] = useState<'live_voice' | 'text_voice'>(config.channel);
  const [interlocutorState, setInterlocutorState] = useState<InterlocutorState>('connecting');
  const [isMinimized, setIsMinimized] = useState(false);
  const [isBrowserFullscreen, setIsBrowserFullscreen] = useState(false);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isAntiEchoGated, setIsAntiEchoGated] = useState(false);
  const [micLevel, setMicLevel] = useState(0);
  const [voiceEnergy, setVoiceEnergy] = useState(0);
  const [voiceBands, setVoiceBands] = useState<number[]>([0, 0, 0, 0, 0, 0, 0, 0]);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [textDraft, setTextDraft] = useState('');
  const [sendingText, setSendingText] = useState(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [infoNotice, setInfoNotice] = useState<string | null>(null);

  // Push-to-talk recorder for Turn-by-turn Voice mode (when Live WebSocket falls back)
  const [isRecordingTurn, setIsRecordingTurn] = useState(false);
  const [transcribingTurn, setTranscribingTurn] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  const stageContainerRef = useRef<HTMLDivElement | null>(null);
  const playbackRef = useRef<PcmPlaybackQueue | null>(null);
  const micRef = useRef<MicCaptureController | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const transcriptRef = useRef<TranscriptEntry[]>(transcript);
  const elapsedRef = useRef(0);
  const isMicMutedRef = useRef(isMicMuted);
  const endedRef = useRef(false);
  const transcriptEndRef = useRef<HTMLDivElement | null>(null);
  const speechSynthActiveRef = useRef(false);

  const activeCandidateIdRef = useRef<string | null>(null);
  const activeInterviewerIdRef = useRef<string | null>(null);

  useEffect(() => {
    transcriptRef.current = transcript;
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcript]);

  useEffect(() => {
    isMicMutedRef.current = isMicMuted;
  }, [isMicMuted]);

  const appendOrMergeTurn = useCallback(
    (speaker: 'candidate' | 'interviewer', deltaText: string) => {
      const cleaned = deltaText;
      if (!cleaned) return;

      const now = new Date();
      const timestamp = now.toLocaleTimeString('fr-FR', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });

      const activeIdRef =
        speaker === 'candidate' ? activeCandidateIdRef : activeInterviewerIdRef;
      const otherIdRef =
        speaker === 'candidate' ? activeInterviewerIdRef : activeCandidateIdRef;
      otherIdRef.current = null;

      onTranscriptChange((prev) => {
        const existingId = activeIdRef.current;
        if (existingId) {
          const idx = prev.findIndex((item) => item.id === existingId);
          if (idx !== -1) {
            const updated = [...prev];
            const prevText = updated[idx].text;
            const needsSpace =
              prevText.length > 0 &&
              !prevText.endsWith(' ') &&
              !cleaned.startsWith(' ') &&
              !/^[.,!?;:’']/.test(cleaned);
            updated[idx] = {
              ...updated[idx],
              text: `${prevText}${needsSpace ? ' ' : ''}${cleaned}`.trim(),
            };
            return updated;
          }
        }

        const newId = `${speaker}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        activeIdRef.current = newId;
        return [
          ...prev,
          {
            id: newId,
            speaker,
            text: cleaned.trim(),
            timestamp,
            elapsedSeconds: elapsedRef.current,
          },
        ];
      });
    },
    [onTranscriptChange]
  );

  const cleanupResources = useCallback(() => {
    if (micRef.current) {
      micRef.current.stop();
      micRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // ignore
      }
      mediaRecorderRef.current = null;
    }
    if (wsRef.current) {
      try {
        if (wsRef.current.readyState === WebSocket.OPEN) {
          wsRef.current.send(JSON.stringify({ type: 'stop' }));
        }
        wsRef.current.close();
      } catch {
        // ignore
      }
      wsRef.current = null;
    }
    if (playbackRef.current) {
      playbackRef.current.destroy();
      playbackRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    speechSynthActiveRef.current = false;
  }, []);

  const triggerEndSession = useCallback(() => {
    if (endedRef.current) return;
    endedRef.current = true;
    cleanupResources();
    if (document.fullscreenElement) {
      void document.exitFullscreen().catch(() => {});
    }
    onFinishSession(transcriptRef.current, elapsedRef.current);
  }, [cleanupResources, onFinishSession]);

  const speakWithFallback = useCallback(
    async (replyText: string, audioBase64Wav?: string) => {
      const queue = playbackRef.current;
      if (audioBase64Wav && queue) {
        setInterlocutorState('speaking');
        await queue.playWavBase64(audioBase64Wav);
        return;
      }

      if ('speechSynthesis' in window && replyText.trim()) {
        await new Promise<void>((resolve) => {
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(replyText);
          const langOpt = LANGUAGE_OPTIONS.find((l) => l.code === config.language);
          utterance.lang = langOpt?.ttsLocale || 'fr-FR';
          speechSynthActiveRef.current = true;
          setInterlocutorState('speaking');

          const finish = () => {
            speechSynthActiveRef.current = false;
            resolve();
          };
          utterance.onend = finish;
          utterance.onerror = finish;
          window.speechSynthesis.speak(utterance);
        });
      }
    },
    [config.language]
  );

  // 60fps Audio Analyser loop for portrait reactivity & anti-echo indicator
  useEffect(() => {
    let rafId = 0;
    const tick = () => {
      const queue = playbackRef.current;
      if (speechSynthActiveRef.current) {
        const t = performance.now() / 120;
        const synthEnergy = 0.28 + Math.abs(Math.sin(t)) * 0.45;
        setVoiceEnergy(synthEnergy);
        setVoiceBands(
          Array.from({ length: 8 }, (_, idx) =>
            Math.min(1, 0.2 + Math.abs(Math.sin(t + idx * 0.7)) * 0.65)
          )
        );
      } else if (queue) {
        const playing = queue.isPlaying(220);
        const { rms, bands } = queue.getEnergy();
        setVoiceEnergy(rms);
        setVoiceBands(bands);

        const gated =
          playing && config.antiEchoProtection && !config.allowInterruptions;
        setIsAntiEchoGated(gated);

        setInterlocutorState((prev) => {
          if (prev === 'connecting') return prev;
          if (playing && rms > 0.015) return 'speaking';
          if (prev === 'speaking' && !playing) return 'listening';
          return prev;
        });
      }
      rafId = requestAnimationFrame(tick);
    };
    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [config.allowInterruptions, config.antiEchoProtection]);

  // 8-minute countdown timer
  useEffect(() => {
    const timer = window.setInterval(() => {
      setElapsedSeconds((prev) => {
        const next = prev + 1;
        elapsedRef.current = next;
        onElapsedChange?.(next);
        if (next >= SESSION_DURATION_SECONDS) {
          window.clearInterval(timer);
          triggerEndSession();
        }
        return next;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [onElapsedChange, triggerEndSession]);

  // Browser fullscreen listener
  useEffect(() => {
    const onFsChange = () => {
      setIsBrowserFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  // Initialize Live Voice (WebSocket) or Turn-based Voice+Text mode
  useEffect(() => {
    let cancelled = false;
    const queue = new PcmPlaybackQueue();
    playbackRef.current = queue;

    const startTurnBasedSession = async () => {
      setInterlocutorState('thinking');
      try {
        const res = await fetch('/api/interview/turn', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            config,
            history: transcriptRef.current.map((t) => ({
              speaker: t.speaker,
              text: t.text,
            })),
            withAudio: true,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Erreur de démarrage');
        if (cancelled) return;

        appendOrMergeTurn('interviewer', data.replyText);
        activeInterviewerIdRef.current = null;
        await speakWithFallback(data.replyText, data.audioBase64Wav);
        if (!cancelled) {
          setInterlocutorState('listening');
        }
      } catch (err) {
        if (!cancelled) {
          setErrorBanner(
            err instanceof Error ? err.message : 'Erreur de connexion au serveur Gemini.'
          );
          setInterlocutorState('listening');
        }
      }
    };

    const startLiveVoiceSession = async () => {
      setInterlocutorState('connecting');
      setErrorBanner(null);

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws/live`);
      wsRef.current = ws;

      ws.onopen = async () => {
        if (cancelled) return;
        ws.send(JSON.stringify({ type: 'start', config }));

        try {
          const micController = await startMicCapture({
            onPcm40ms: (base64Pcm) => {
              if (ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: 'audio', audio: base64Pcm }));
              }
            },
            onLevel: (lvl) => setMicLevel(lvl),
            shouldGate: () => {
              if (isMicMutedRef.current) return true;
              if (config.antiEchoProtection && !config.allowInterruptions) {
                return queue.isPlaying(240);
              }
              return false;
            },
          });
          if (cancelled) {
            micController.stop();
          } else {
            micRef.current = micController;
          }
        } catch {
          if (!cancelled) {
            setInfoNotice(
              'Microphone inaccessible : répondez par écrit ou autorisez le micro dans votre navigateur.'
            );
            setIsMicMuted(true);
          }
        }
      };

      ws.onmessage = (event) => {
        if (cancelled) return;
        try {
          const msg = JSON.parse(event.data) as {
            type: string;
            audio?: string;
            text?: string;
            message?: string;
          };

          if (msg.type === 'ready') {
            setInterlocutorState('thinking');
          } else if (msg.type === 'audio' && msg.audio) {
            setInterlocutorState('speaking');
            queue.enqueuePcm24k(msg.audio);
          } else if (msg.type === 'input_transcript' && msg.text) {
            appendOrMergeTurn('candidate', msg.text);
          } else if (msg.type === 'output_transcript' && msg.text) {
            appendOrMergeTurn('interviewer', msg.text);
          } else if (msg.type === 'interrupted') {
            queue.clear();
            activeInterviewerIdRef.current = null;
            setInterlocutorState('listening');
          } else if (msg.type === 'turn_complete') {
            activeInterviewerIdRef.current = null;
            activeCandidateIdRef.current = null;
            if (!queue.isPlaying(50)) {
              setInterlocutorState('listening');
            }
          } else if (msg.type === 'live_unavailable') {
            // Seamless transition to Turn-by-Turn Voice + Text Gemini pipeline without breaking UX
            cleanupResources();
            setInfoNotice(
              'Mode conversation structurée activé (Voix par tour + Texte) pour une stabilité optimale.'
            );
            setChannel('text_voice');
          } else if (msg.type === 'error') {
            setErrorBanner(msg.message || 'Erreur de flux Gemini Live.');
            setInterlocutorState('listening');
          } else if (msg.type === 'closed') {
            if (!endedRef.current && transcriptRef.current.some((t) => t.speaker === 'candidate')) {
              setInfoNotice(
                'La connexion vocale directe s’est terminée. Vous pouvez continuer par écrit ou générer le bilan.'
              );
            }
          }
        } catch {
          // ignore malformed ws message
        }
      };

      ws.onerror = () => {
        if (!cancelled) {
          cleanupResources();
          setInfoNotice(
            'Bascule automatique vers le mode Voix par tour + Texte pour poursuivre sans coupure.'
          );
          setChannel('text_voice');
        }
      };
    };

    if (channel === 'live_voice') {
      void startLiveVoiceSession();
    } else {
      void startTurnBasedSession();
    }

    return () => {
      cancelled = true;
      cleanupResources();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [channel]);

  const handleSendText = async (e?: React.FormEvent, overrideText?: string) => {
    if (e) e.preventDefault();
    const message = (overrideText ?? textDraft).trim();
    if (!message || sendingText) return;

    if (!overrideText) setTextDraft('');
    activeCandidateIdRef.current = null;
    activeInterviewerIdRef.current = null;
    appendOrMergeTurn('candidate', message);
    activeCandidateIdRef.current = null;

    if (channel === 'live_voice' && wsRef.current?.readyState === WebSocket.OPEN) {
      setInterlocutorState('thinking');
      wsRef.current.send(JSON.stringify({ type: 'text', text: message }));
      return;
    }

    setSendingText(true);
    setInterlocutorState('thinking');
    setErrorBanner(null);

    try {
      const historyPayload = transcriptRef.current.map((t) => ({
        speaker: t.speaker,
        text: t.text,
      }));
      const res = await fetch('/api/interview/turn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          config,
          history: historyPayload,
          candidateMessage: message,
          withAudio: true,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erreur lors de l’échange.');

      appendOrMergeTurn('interviewer', data.replyText);
      activeInterviewerIdRef.current = null;

      await speakWithFallback(data.replyText, data.audioBase64Wav);
      setInterlocutorState('listening');
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : 'Erreur réseau.');
      setInterlocutorState('listening');
    } finally {
      setSendingText(false);
    }
  };

  // Push-to-talk recording in Turn-based Voice mode
  const handleToggleTurnRecord = async () => {
    if (isRecordingTurn && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecordingTurn(false);
      return;
    }

    setErrorBanner(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : 'audio/webm';
      const recorder = new MediaRecorder(stream, { mimeType });
      recordedChunksRef.current = [];

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) recordedChunksRef.current.push(ev.data);
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(recordedChunksRef.current, { type: mimeType });
        if (blob.size < 400) return;

        setTranscribingTurn(true);
        setInterlocutorState('thinking');
        try {
          const base64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
              const result = String(reader.result || '');
              resolve(result.split(',')[1] || '');
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });

          const res = await fetch('/api/transcribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: base64,
              mimeType: 'audio/webm',
              language: config.language,
            }),
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || 'Transcription impossible.');

          if (data.text?.trim()) {
            await handleSendText(undefined, data.text.trim());
          } else {
            setInterlocutorState('listening');
          }
        } catch (err) {
          setErrorBanner(
            err instanceof Error ? err.message : 'Erreur lors de la transcription audio.'
          );
          setInterlocutorState('listening');
        } finally {
          setTranscribingTurn(false);
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecordingTurn(true);
    } catch {
      setErrorBanner(
        "Impossible d'accéder au microphone. Utilisez le champ texte ci-dessous pour répondre."
      );
    }
  };

  const handleToggleFullscreen = async () => {
    if (!stageContainerRef.current) return;
    try {
      if (!document.fullscreenElement) {
        await stageContainerRef.current.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      // ignore unsupported fullscreen
    }
  };

  const remainingSeconds = Math.max(0, SESSION_DURATION_SECONDS - elapsedSeconds);
  const isNearEnd = remainingSeconds <= 60;
  const langLabel =
    LANGUAGE_OPTIONS.find((l) => l.code === config.language)?.label || config.language;

  return (
    <div
      ref={stageContainerRef}
      className={`${
        isMinimized
          ? 'mx-auto max-w-6xl px-4 py-6 sm:px-6'
          : 'min-h-[calc(100vh-65px)] bg-slate-950 text-white px-4 py-4 sm:px-6 sm:py-6 flex flex-col'
      }`}
    >
      {/* Subtle Info Notice */}
      {infoNotice && !errorBanner && (
        <div
          className={`mb-3 flex items-center justify-between gap-3 rounded-xl border px-4 py-2.5 text-xs ${
            isMinimized
              ? 'border-blue-200 bg-blue-50 text-blue-900'
              : 'border-sky-500/30 bg-slate-900/90 text-sky-100'
          }`}
        >
          <span>{infoNotice}</span>
          <button
            type="button"
            onClick={() => setInfoNotice(null)}
            className="text-xs font-semibold opacity-75 hover:opacity-100"
          >
            Masquer
          </button>
        </div>
      )}

      {/* Error / Fallback Banner */}
      {errorBanner && (
        <div
          role="alert"
          className={`mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border px-4 py-3 text-xs sm:text-sm ${
            isMinimized
              ? 'border-amber-200 bg-amber-50 text-amber-900'
              : 'border-amber-500/40 bg-amber-950/70 text-amber-100'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="h-4 w-4 shrink-0 text-amber-500" aria-hidden="true" />
            <span>{errorBanner}</span>
          </div>
          {channel === 'live_voice' && (
            <button
              type="button"
              onClick={() => {
                cleanupResources();
                setErrorBanner(null);
                setChannel('text_voice');
              }}
              className="rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-amber-700 transition-colors whitespace-nowrap"
            >
              Basculer en Voix par tour + Texte
            </button>
          )}
        </div>
      )}

      {/* Main Layout: Fullscreen Video OR Minimized Split View */}
      <div
        className={
          isMinimized
            ? 'grid grid-cols-1 gap-6 lg:grid-cols-12'
            : 'mx-auto flex w-full max-w-6xl flex-1 flex-col gap-4'
        }
      >
        <div className={isMinimized ? 'lg:col-span-5 space-y-4' : 'flex-1 flex flex-col'}>
          <InterlocutorStage
            mode={config.mode}
            visualStyle={config.visualStyle}
            state={interlocutorState}
            voiceEnergy={voiceEnergy}
            voiceBands={voiceBands}
            candidateLevel={micLevel}
            role={config.role}
            country={config.country}
            isMinimized={isMinimized}
            isBrowserFullscreen={isBrowserFullscreen}
            onToggleMinimize={() => setIsMinimized((v) => !v)}
            onToggleBrowserFullscreen={handleToggleFullscreen}
            onChangeVisualStyle={onUpdateVisualStyle}
          />

          {isMinimized && (
            <div className="rounded-xl border border-slate-200 bg-white p-4 text-xs text-slate-600 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-900">Paramètres verrouillés</span>
                <span className="font-mono font-semibold text-slate-800">
                  {formatDuration(remainingSeconds)}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <div>
                  <span className="text-slate-400">Mode :</span>{' '}
                  <span className="font-medium text-slate-800">
                    {config.mode === 'recruiter' ? 'Recruteur' : 'Coach'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400">Langue :</span>{' '}
                  <span className="font-medium text-slate-800">{langLabel}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-400">Poste :</span>{' '}
                  <span className="font-medium text-slate-800">
                    {config.role} ({config.country})
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Minimized Live Transcript & Coach Panel */}
        {isMinimized && (
          <div className="lg:col-span-7 flex flex-col rounded-2xl border border-slate-200 bg-white overflow-hidden h-[520px]">
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3.5">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-blue-700" aria-hidden="true" />
                <h2 className="font-display text-sm font-bold text-slate-900">
                  Transcription en direct
                </h2>
              </div>
              <span className="text-xs text-slate-500">
                {transcript.length} échange{transcript.length > 1 ? 's' : ''}
              </span>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-slate-50/50">
              {transcript.length === 0 ? (
                <p className="text-sm text-slate-500">
                  L’interlocuteur prépare sa première question...
                </p>
              ) : (
                transcript.map((entry) => (
                  <div
                    key={entry.id}
                    className={`flex flex-col ${
                      entry.speaker === 'candidate' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div className="mb-1 flex items-center gap-2 text-[11px] text-slate-400">
                      <span className="font-medium text-slate-600">
                        {entry.speaker === 'candidate'
                          ? 'Vous'
                          : config.mode === 'recruiter'
                          ? 'Recruteur'
                          : 'Coach'}
                      </span>
                      <span className="font-mono">{entry.timestamp}</span>
                    </div>
                    <div
                      className={`max-w-[85%] rounded-xl px-4 py-2.5 text-sm leading-relaxed ${
                        entry.speaker === 'candidate'
                          ? 'bg-blue-700 text-white'
                          : 'border border-slate-200 bg-white text-slate-800'
                      }`}
                    >
                      {entry.text}
                    </div>
                  </div>
                ))
              )}
              <div ref={transcriptEndRef} />
            </div>

            <form
              onSubmit={handleSendText}
              className="border-t border-slate-200 bg-white p-3 flex items-center gap-2"
            >
              <input
                type="text"
                value={textDraft}
                onChange={(e) => setTextDraft(e.target.value)}
                placeholder="Répondre par écrit ou compléter votre réponse..."
                className="flex-1 rounded-lg border border-slate-300 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
              />
              <button
                type="submit"
                disabled={!textDraft.trim() || sendingText}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-50 transition-colors min-h-[40px]"
              >
                <Send className="h-4 w-4" aria-hidden="true" />
                <span>Envoyer</span>
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Bottom Videoconference Control Dock */}
      <div
        className={`mx-auto mt-4 w-full max-w-6xl rounded-2xl border p-3 sm:px-5 sm:py-3.5 ${
          isMinimized
            ? 'border-slate-200 bg-white text-slate-900'
            : 'border-slate-800 bg-slate-900/95 text-white'
        }`}
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2.5">
            {channel === 'live_voice' ? (
              <>
                <button
                  type="button"
                  onClick={() => setIsMicMuted((m) => !m)}
                  className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs sm:text-sm font-semibold transition-colors min-h-[44px] ${
                    isMicMuted
                      ? 'bg-rose-600 text-white hover:bg-rose-700'
                      : isAntiEchoGated
                      ? 'bg-amber-600/20 text-amber-300 border border-amber-500/40'
                      : isMinimized
                      ? 'bg-slate-900 text-white hover:bg-slate-800'
                      : 'bg-slate-800 text-white hover:bg-slate-700 border border-slate-700'
                  }`}
                >
                  {isMicMuted ? (
                    <>
                      <MicOff className="h-4 w-4" aria-hidden="true" />
                      <span>Micro coupé</span>
                    </>
                  ) : (
                    <>
                      <Mic className="h-4 w-4 text-emerald-400" aria-hidden="true" />
                      <span>
                        {isAntiEchoGated ? 'Micro en pause (anti-écho)' : 'Micro actif'}
                      </span>
                    </>
                  )}
                </button>

                {!isMicMuted && !isAntiEchoGated && (
                  <div
                    className="hidden sm:flex items-center gap-1.5 px-2"
                    aria-label="Niveau du microphone"
                  >
                    <div className="h-2 w-16 overflow-hidden rounded-full bg-slate-700/60">
                      <div
                        className="h-full rounded-full bg-emerald-400 transition-all duration-75"
                        style={{ width: `${Math.round(micLevel * 100)}%` }}
                      />
                    </div>
                  </div>
                )}

                <span
                  className={`hidden md:inline-flex items-center gap-1.5 text-xs ${
                    isMinimized ? 'text-slate-500' : 'text-slate-400'
                  }`}
                >
                  {config.allowInterruptions ? (
                    <>
                      <Headphones className="h-3.5 w-3.5 text-sky-400" aria-hidden="true" />
                      <span>Mode casque (interruptions actives)</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                      <span>Anti-écho actif</span>
                    </>
                  )}
                </span>
              </>
            ) : (
              /* Push-to-talk vocal button in Turn-based mode */
              <button
                type="button"
                onClick={() => void handleToggleTurnRecord()}
                disabled={transcribingTurn || sendingText}
                className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs sm:text-sm font-semibold transition-colors min-h-[44px] ${
                  isRecordingTurn
                    ? 'bg-rose-600 text-white hover:bg-rose-700'
                    : isMinimized
                    ? 'bg-slate-900 text-white hover:bg-slate-800'
                    : 'bg-slate-800 text-white hover:bg-slate-700 border border-slate-700'
                }`}
              >
                {transcribingTurn ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin text-sky-400" aria-hidden="true" />
                    <span>Transcription...</span>
                  </>
                ) : isRecordingTurn ? (
                  <>
                    <Square className="h-4 w-4 fill-current" aria-hidden="true" />
                    <span>Arrêter et envoyer ma réponse</span>
                  </>
                ) : (
                  <>
                    <Mic className="h-4 w-4 text-emerald-400" aria-hidden="true" />
                    <span>Répondre à l’oral</span>
                  </>
                )}
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2.5 ml-auto">
            {config.mode === 'coach' && (
              <button
                type="button"
                onClick={() =>
                  void handleSendText(
                    undefined,
                    config.language === 'en'
                      ? 'Can you give me a quick hint or STAR structure tip for this question?'
                      : config.language === 'ary'
                      ? 'عافاك واش تقدر تعطيني نصيحة خفيفة ولا مثال باش نجاوب مزيان؟'
                      : 'Pouvez-vous me donner un indice ou un conseil de structure STAR pour bien répondre ?'
                  )
                }
                className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-2.5 text-xs font-medium transition-colors min-h-[44px] ${
                  isMinimized
                    ? 'border-slate-300 bg-slate-50 text-slate-800 hover:bg-slate-100'
                    : 'border-slate-700 bg-slate-800/80 text-slate-200 hover:bg-slate-800'
                }`}
              >
                <Sparkles className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                <span>Indice Coach</span>
              </button>
            )}

            <div
              className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-2 font-mono text-xs sm:text-sm font-semibold min-h-[44px] ${
                isNearEnd
                  ? 'border-amber-500/60 bg-amber-500/15 text-amber-400'
                  : isMinimized
                  ? 'border-slate-200 bg-slate-50 text-slate-800'
                  : 'border-slate-800 bg-slate-950 text-slate-200'
              }`}
              title="Durée maximale de la session : 8 minutes"
            >
              <Clock className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{formatDuration(remainingSeconds)}</span>
            </div>

            <button
              type="button"
              onClick={triggerEndSession}
              className="inline-flex items-center gap-2 rounded-xl bg-rose-600 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white hover:bg-rose-700 active:scale-[0.99] transition-all min-h-[44px] whitespace-nowrap"
            >
              <PhoneOff className="h-4 w-4" aria-hidden="true" />
              <span>Terminer et recevoir le bilan</span>
            </button>
          </div>
        </div>

        {/* Inline text input bar when in full-screen videoconference */}
        {!isMinimized && (
          <form
            onSubmit={handleSendText}
            className="mt-3 flex items-center gap-2 border-t border-slate-800 pt-3"
          >
            <input
              type="text"
              value={textDraft}
              onChange={(e) => setTextDraft(e.target.value)}
              placeholder={
                channel === 'text_voice'
                  ? 'Tapez votre réponse ici ou utilisez « Répondre à l’oral »...'
                  : 'Optionnel : envoyer une réponse écrite ou poser une précision...'
              }
              className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none min-h-[44px]"
            />
            <button
              type="submit"
              disabled={!textDraft.trim() || sendingText}
              className="inline-flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50 transition-colors min-h-[44px] whitespace-nowrap"
            >
              {sendingText ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <Send className="h-4 w-4" aria-hidden="true" />
              )}
              <span>Envoyer</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
