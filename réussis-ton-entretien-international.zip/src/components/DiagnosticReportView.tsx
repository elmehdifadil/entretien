import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Copy,
  Download,
  Loader2,
  MessageSquareText,
  Printer,
  RotateCcw,
  Square,
  Volume2,
} from 'lucide-react';
import {
  LANGUAGE_OPTIONS,
  type DiagnosticReport,
  type InterviewConfig,
  type TranscriptEntry,
} from '../types/interview';
import { buildReportDownloadText, formatDuration } from '../utils/storage';

interface DiagnosticReportViewProps {
  config: InterviewConfig;
  transcript: TranscriptEntry[];
  durationSeconds: number;
  report: DiagnosticReport | null;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onNewInterview: () => void;
}

export const DiagnosticReportView: React.FC<DiagnosticReportViewProps> = ({
  config,
  transcript,
  durationSeconds,
  report,
  loading,
  error,
  onRetry,
  onNewInterview,
}) => {
  const [copied, setCopied] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);
  const [ttsState, setTtsState] = useState<'idle' | 'loading' | 'playing'>('idle');
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const langOption = LANGUAGE_OPTIONS.find((l) => l.code === config.language);
  const hasCandidateTurns = transcript.some(
    (t) => t.speaker === 'candidate' && t.text.trim().length > 0
  );

  const handleDownload = () => {
    if (!report) return;
    const content = buildReportDownloadText({ config, report, transcript });
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bilan-entretien-${config.country.toLowerCase().replace(/\s+/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopy = async () => {
    if (!report) return;
    const content = buildReportDownloadText({ config, report, transcript });
    await navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleToggleReadAloud = async () => {
    if (!report) return;

    if (ttsState === 'playing') {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setTtsState('idle');
      return;
    }

    const speechText = [
      report.executiveSummary,
      ...report.axes.map((a) => `${a.label}: ${a.score} / 20. ${a.advice}`),
      ...report.nextSteps,
    ].join(' ');

    setTtsState('loading');
    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: speechText }),
      });
      const data = await res.json();
      if (!res.ok || !data.audioBase64Wav) {
        throw new Error('TTS fallback');
      }
      const binary = atob(data.audioBase64Wav);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: 'audio/wav' });
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.onended = () => {
        URL.revokeObjectURL(url);
        audioRef.current = null;
        setTtsState('idle');
      };
      audio.onerror = () => {
        URL.revokeObjectURL(url);
        setTtsState('idle');
      };
      setTtsState('playing');
      await audio.play();
    } catch {
      // Fallback to browser SpeechSynthesis (V6 optional read-aloud)
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(speechText);
        utterance.lang = langOption?.ttsLocale || 'fr-FR';
        utterance.onend = () => setTtsState('idle');
        utterance.onerror = () => setTtsState('idle');
        setTtsState('playing');
        window.speechSynthesis.speak(utterance);
      } else {
        setTtsState('idle');
      }
    }
  };

  if (loading) {
    return (
      <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 sm:p-10 text-center">
          <Loader2 className="mx-auto h-8 w-8 animate-spin text-blue-700" aria-hidden="true" />
          <h1 className="font-display mt-4 text-xl font-bold text-slate-900">
            Analyse de votre entretien en cours
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            Évaluation des 5 axes à partir de la transcription réelle ({transcript.length} tours de
            parole)...
          </p>
        </div>
      </main>
    );
  }

  if (error || !report) {
    return (
      <main className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <div className="rounded-2xl border border-slate-200 bg-white p-8">
          <div className="flex items-start gap-3">
            <AlertCircle className="mt-0.5 h-6 w-6 shrink-0 text-rose-600" aria-hidden="true" />
            <div>
              <h1 className="font-display text-lg font-bold text-slate-900">
                {hasCandidateTurns
                  ? 'Impossible de finaliser le diagnostic'
                  : 'Aucune réponse transcrite'}
              </h1>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">
                {error ||
                  "Aucune prise de parole du candidat n'a été enregistrée durant cette session. Le bilan nécessite au moins une réponse."}
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                {hasCandidateTurns && (
                  <button
                    type="button"
                    onClick={onRetry}
                    className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 transition-colors"
                  >
                    <RotateCcw className="h-4 w-4" aria-hidden="true" />
                    <span>Réessayer l’analyse</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={onNewInterview}
                  className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-800 hover:bg-slate-50 transition-colors"
                >
                  <span>Nouvel entretien</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:py-10 space-y-8">
      {/* Header Summary Card */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <div className="flex flex-wrap items-start justify-between gap-6 border-b border-slate-200 pb-6">
          <div className="max-w-2xl">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span>{config.mode === 'recruiter' ? 'Mode Recruteur' : 'Mode Coach'}</span>
              <span aria-hidden="true">·</span>
              <span>{config.country}</span>
              <span aria-hidden="true">·</span>
              <span>{langOption?.label || config.language}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">Durée {formatDuration(durationSeconds)}</span>
            </div>
            <h1 className="font-display mt-2 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
              Bilan de votre entretien : {config.role}
            </h1>
            <p className="mt-1.5 text-sm font-medium text-blue-700">{report.readinessLevel}</p>
          </div>

          {/* Numeric Score Display */}
          <div className="flex items-baseline gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-5 py-3.5">
            <span className="font-mono text-4xl font-bold tracking-tight text-slate-900">
              {report.overallScore}
            </span>
            <span className="font-mono text-sm font-medium text-slate-500">/ 100</span>
          </div>
        </div>

        <p className="mt-6 text-base leading-relaxed text-slate-700">{report.executiveSummary}</p>

        <p className="mt-4 text-xs text-slate-500">
          Évaluation fondée uniquement sur les éléments observables dans la transcription écrite de
          l’entretien (sans analyse acoustique de la prononciation ou du débit).
        </p>

        {/* Actions Bar */}
        <div className="no-print mt-6 flex flex-wrap items-center gap-2.5 border-t border-slate-200 pt-5">
          <button
            type="button"
            onClick={handleToggleReadAloud}
            disabled={ttsState === 'loading'}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs sm:text-sm font-semibold text-slate-800 hover:bg-slate-50 transition-colors min-h-[40px]"
          >
            {ttsState === 'loading' ? (
              <Loader2 className="h-4 w-4 animate-spin text-blue-700" aria-hidden="true" />
            ) : ttsState === 'playing' ? (
              <Square className="h-4 w-4 text-rose-600 fill-current" aria-hidden="true" />
            ) : (
              <Volume2 className="h-4 w-4 text-blue-700" aria-hidden="true" />
            )}
            <span>
              {ttsState === 'playing'
                ? 'Arrêter la lecture'
                : ttsState === 'loading'
                ? 'Préparation audio...'
                : 'Écouter le bilan'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleDownload}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs sm:text-sm font-semibold text-slate-800 hover:bg-slate-50 transition-colors min-h-[40px]"
          >
            <Download className="h-4 w-4" aria-hidden="true" />
            <span>Télécharger (.txt)</span>
          </button>

          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs sm:text-sm font-semibold text-slate-800 hover:bg-slate-50 transition-colors min-h-[40px]"
          >
            <Copy className="h-4 w-4" aria-hidden="true" />
            <span>{copied ? 'Copié' : 'Copier'}</span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs sm:text-sm font-semibold text-slate-800 hover:bg-slate-50 transition-colors min-h-[40px]"
          >
            <Printer className="h-4 w-4" aria-hidden="true" />
            <span>Imprimer / PDF</span>
          </button>

          <button
            type="button"
            onClick={onNewInterview}
            className="ml-auto inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-xs sm:text-sm font-semibold text-white hover:bg-blue-800 transition-colors min-h-[40px]"
          >
            <span>Nouvel entretien</span>
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </section>

      {/* 5-Axis Evaluation Matrix */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <h2 className="font-display text-lg font-bold text-slate-900">
          Diagnostic détaillé sur 5 axes
        </h2>
        <div className="mt-5 divide-y divide-slate-200">
          {report.axes.map((axis, idx) => {
            const pct = Math.round((axis.score / (axis.maxScore || 20)) * 100);
            const barColor =
              pct >= 75 ? 'bg-emerald-600' : pct >= 55 ? 'bg-blue-600' : 'bg-amber-600';
            return (
              <div key={axis.id || idx} className="py-5 first:pt-2 last:pb-0">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="font-display text-base font-semibold text-slate-900">
                    {idx + 1}. {axis.label}
                  </h3>
                  <span className="font-mono text-sm font-bold text-slate-900">
                    {axis.score} / {axis.maxScore || 20}
                  </span>
                </div>
                <div className="mt-2.5 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${barColor}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2 text-sm leading-relaxed">
                  <div className="text-slate-600">
                    <span className="font-semibold text-slate-800">Constat : </span>
                    {axis.observation}
                  </div>
                  <div className="text-slate-600">
                    <span className="font-semibold text-slate-800">Recommandation : </span>
                    {axis.advice}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Strengths & Improvements */}
      <section className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-6">
          <h2 className="font-display text-base font-bold text-slate-900">Points forts observés</h2>
          <ul className="mt-4 space-y-2.5 text-sm leading-relaxed text-slate-700">
            {report.strengths.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2.5">
                <CheckCircle2
                  className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600"
                  aria-hidden="true"
                />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6">
          <h2 className="font-display text-base font-bold text-slate-900">
            Axes prioritaires de progression
          </h2>
          <ul className="mt-4 space-y-2.5 text-sm leading-relaxed text-slate-700">
            {report.improvements.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2.5">
                <ArrowRight
                  className="mt-0.5 h-4 w-4 shrink-0 text-blue-700"
                  aria-hidden="true"
                />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Reformulation Workshop */}
      {report.reformulations.length > 0 && (
        <section className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
          <h2 className="font-display text-lg font-bold text-slate-900">
            Atelier de reformulation STAR
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Exemples concrets issus de vos réponses avec une formulation plus percutante pour{' '}
            {config.country}.
          </p>

          <div className="mt-5 space-y-5 divide-y divide-slate-200">
            {report.reformulations.map((item, idx) => (
              <div key={idx} className="pt-5 first:pt-0 space-y-3">
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                    <div className="text-xs font-semibold text-slate-500">
                      Ce que vous avez dit
                    </div>
                    <p className="mt-1.5 text-sm leading-relaxed text-slate-700">
                      « {item.original} »
                    </p>
                  </div>
                  <div className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-4">
                    <div className="text-xs font-semibold text-emerald-800">
                      Formulation recommandée
                    </div>
                    <p className="mt-1.5 text-sm leading-relaxed text-slate-900 font-medium">
                      « {item.improved} »
                    </p>
                  </div>
                </div>
                <p className="text-xs text-slate-600">
                  <span className="font-semibold text-slate-800">Impact : </span>
                  {item.rationale}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Next Steps & Transcript Toggle */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <h2 className="font-display text-base font-bold text-slate-900">
          Plan d’action avant votre vrai entretien
        </h2>
        <ol className="mt-3 list-decimal pl-5 space-y-2 text-sm leading-relaxed text-slate-700">
          {report.nextSteps.map((step, idx) => (
            <li key={idx}>{step}</li>
          ))}
        </ol>

        <div className="no-print mt-6 border-t border-slate-200 pt-5">
          <button
            type="button"
            onClick={() => setShowTranscript((v) => !v)}
            className="inline-flex items-center gap-2 text-sm font-semibold text-blue-700 hover:text-blue-800"
          >
            <MessageSquareText className="h-4 w-4" aria-hidden="true" />
            <span>
              {showTranscript
                ? 'Masquer la transcription complète'
                : `Afficher la transcription complète (${transcript.length} échanges)`}
            </span>
          </button>

          {showTranscript && (
            <div className="mt-4 max-h-96 overflow-y-auto rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
              {transcript.map((t) => (
                <div key={t.id} className="text-sm leading-relaxed">
                  <span className="font-mono text-xs text-slate-400 mr-2">[{t.timestamp}]</span>
                  <span className="font-semibold text-slate-900 mr-1.5">
                    {t.speaker === 'candidate' ? 'Candidat :' : 'Interlocuteur :'}
                  </span>
                  <span className="text-slate-700">{t.text}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </main>
  );
};
