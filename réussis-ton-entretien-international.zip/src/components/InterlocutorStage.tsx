import React, { useEffect, useState } from 'react';
import {
  AudioLines,
  Box,
  Camera,
  Ear,
  Loader2,
  Maximize2,
  Minimize2,
  Sparkles,
  UserCheck,
  Video,
  Volume2,
} from 'lucide-react';
import type {
  InterlocutorState,
  InterviewMode,
  VisualStyle,
} from '../types/interview';
import { Studio3DCanvas, type CameraPreset } from './Studio3DCanvas';

export const RECRUITER_PORTRAIT_URL =
  '/src/assets/images/recruiter_male_portrait_1795635211817.jpg';
export const COACH_PORTRAIT_URL =
  '/src/assets/images/coach_male_portrait_1795635212450.jpg';

const RECRUITER_FRAMES = {
  idle: RECRUITER_PORTRAIT_URL,
  listening: '/src/assets/images/recruiter_react_listening_1795635811758.jpg',
  thinking: '/src/assets/images/recruiter_react_thinking_1795635811690.jpg',
  speaking: '/src/assets/images/recruiter_react_speaking_1795635812723.jpg',
};

const COACH_FRAMES = {
  idle: COACH_PORTRAIT_URL,
  listening: COACH_PORTRAIT_URL,
  thinking: '/src/assets/images/coach_react_thinking_1795635813827.jpg',
  speaking: '/src/assets/images/coach_react_speaking_1795635813646.jpg',
};

const FLOW_VIDEO_MAP: Record<InterlocutorState, string> = {
  idle: '/flow/recruteur/accueil.mp4',
  connecting: '/flow/recruteur/accueil.mp4',
  listening: '/flow/recruteur/ecoute.mp4',
  thinking: '/flow/recruteur/reflexion.mp4',
  speaking: '/flow/recruteur/parole.mp4',
};

type ReactionKey = 'idle' | 'listening' | 'thinking' | 'speaking';

interface InterlocutorStageProps {
  mode: InterviewMode;
  visualStyle: VisualStyle;
  state: InterlocutorState;
  voiceEnergy: number;
  voiceBands: number[];
  candidateLevel?: number;
  role: string;
  country: string;
  isMinimized: boolean;
  isBrowserFullscreen: boolean;
  onToggleMinimize: () => void;
  onToggleBrowserFullscreen: () => void;
  onChangeVisualStyle: (style: VisualStyle) => void;
}

export const InterlocutorStage: React.FC<InterlocutorStageProps> = ({
  mode,
  visualStyle,
  state,
  voiceEnergy,
  voiceBands,
  candidateLevel = 0,
  role,
  country,
  isMinimized,
  isBrowserFullscreen,
  onToggleMinimize,
  onToggleBrowserFullscreen,
  onChangeVisualStyle,
}) => {
  const [imgFailed, setImgFailed] = useState(false);
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('front');
  const [flowStatus, setFlowStatus] = useState<'idle' | 'loading' | 'active' | 'fallback'>(
    'idle'
  );

  const frames = mode === 'recruiter' ? RECRUITER_FRAMES : COACH_FRAMES;
  const interlocutorName = mode === 'recruiter' ? 'Karim — Recruteur' : 'Marc — Coach Carrière';
  const flowVideoSrc = FLOW_VIDEO_MAP[state] || FLOW_VIDEO_MAP.idle;

  useEffect(() => {
    setImgFailed(false);
  }, [mode]);

  useEffect(() => {
    if (visualStyle === 'flow_video') {
      setFlowStatus('loading');
    } else {
      setFlowStatus('idle');
    }
  }, [visualStyle, flowVideoSrc]);

  // Determine exact visual reaction frame based on state + live voice amplitude
  let activeFrame: ReactionKey = 'idle';
  if (state === 'listening') {
    activeFrame = 'listening';
  } else if (state === 'thinking') {
    activeFrame = 'thinking';
  } else if (state === 'speaking') {
    // Modulate between open-mouth speaking frame and attentive closed-mouth frame with speech cadence
    activeFrame = voiceEnergy > 0.045 ? 'speaking' : 'listening';
  }

  const candidateIsAudible = state === 'listening' && candidateLevel > 0.09;

  const stateDisplay: Record<
    InterlocutorState,
    { label: string; icon: React.ReactNode; toneClass: string }
  > = {
    idle: {
      label: 'Prêt',
      icon: <UserCheck className="h-3.5 w-3.5" aria-hidden="true" />,
      toneClass: 'text-slate-200 bg-slate-900/75 border-slate-700/80',
    },
    connecting: {
      label: 'Connexion studio...',
      icon: <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />,
      toneClass: 'text-sky-200 bg-slate-900/80 border-sky-500/40',
    },
    listening: {
      label: candidateIsAudible ? 'Vous écoute attentivement' : 'À l’écoute',
      icon: <Ear className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />,
      toneClass: candidateIsAudible
        ? 'text-emerald-50 bg-emerald-950/80 border-emerald-400/60'
        : 'text-emerald-100 bg-slate-900/80 border-emerald-500/40',
    },
    thinking: {
      label: 'Analyse votre réponse...',
      icon: <Sparkles className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />,
      toneClass: 'text-amber-100 bg-slate-900/80 border-amber-500/40',
    },
    speaking: {
      label: 'Parole en cours',
      icon: <Volume2 className="h-3.5 w-3.5 text-sky-400" aria-hidden="true" />,
      toneClass: 'text-sky-100 bg-slate-900/80 border-sky-400/50',
    },
  };

  const currentStateInfo = stateDisplay[state];
  const speakingTiltY = state === 'speaking' ? -(voiceEnergy * 2.5) : 0;
  const listeningNodScale = candidateIsAudible ? 1.012 : 1;
  const dynamicScale =
    state === 'speaking' ? 1 + voiceEnergy * 0.018 : listeningNodScale;

  const ringColorClass =
    state === 'speaking'
      ? 'border-sky-400/80'
      : candidateIsAudible
      ? 'border-emerald-400/70'
      : state === 'thinking'
      ? 'border-amber-400/60'
      : 'border-white/10';

  const ringOpacity =
    state === 'speaking'
      ? Math.min(0.95, 0.35 + voiceEnergy * 0.65)
      : candidateIsAudible
      ? Math.min(0.85, 0.35 + candidateLevel * 0.6)
      : state === 'thinking'
      ? 0.55
      : 0;

  return (
    <div
      className={`relative overflow-hidden bg-slate-950 text-white select-none transition-all duration-200 ${
        isMinimized
          ? 'rounded-xl border border-slate-800 aspect-video max-h-[340px] w-full'
          : 'rounded-2xl border border-slate-800/90 h-full min-h-[420px] lg:min-h-[540px] w-full'
      }`}
    >
      {/* Blurred ambient copy behind centered portrait (V9 no-stretch wide-screen framing) */}
      {visualStyle !== 'voice_only' && visualStyle !== 'avatar_3d' && !imgFailed && (
        <img
          src={frames.idle}
          alt=""
          aria-hidden="true"
          referrerPolicy="no-referrer"
          className="pointer-events-none absolute inset-0 h-full w-full scale-110 object-cover opacity-35 blur-2xl"
        />
      )}

      {/* Subtle studio vignette (omitted over full-bleed 3D WebGL canvas) */}
      {visualStyle !== 'avatar_3d' && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-slate-950/60"
        />
      )}

      {/* Full-bleed Three.js 3D Studio Layer when avatar_3d is active */}
      {visualStyle === 'avatar_3d' && (
        <div className="absolute inset-0 z-0">
          <Studio3DCanvas
            mode={mode}
            state={state}
            voiceEnergy={voiceEnergy}
            candidateLevel={candidateLevel}
            cameraPreset={cameraPreset}
            className="h-full w-full"
          />
        </div>
      )}

      {/* Top overlay bar inside video stage */}
      <div className="pointer-events-none relative z-10 flex flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-5">
        <div className="pointer-events-auto flex flex-wrap items-center gap-2.5">
          <span
            className={`inline-flex items-center gap-2 rounded-lg border px-2.5 py-1 text-xs font-medium transition-colors ${
              visualStyle === 'avatar_3d' ? '' : 'backdrop-blur-md'
            } ${currentStateInfo.toneClass}`}
          >
            {currentStateInfo.icon}
            <span>{currentStateInfo.label}</span>
          </span>

          <span className="hidden sm:inline rounded-md bg-slate-950/75 px-2 py-0.5 text-xs text-slate-300/95">
            {interlocutorName} · {role} ({country})
          </span>

          {visualStyle === 'flow_video' && (
            <span className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/75 px-2.5 py-1 text-xs text-slate-200">
              <Video className="h-3.5 w-3.5 text-sky-400" aria-hidden="true" />
              <span>
                {flowStatus === 'active'
                  ? 'Vidéo Flow active'
                  : flowStatus === 'loading'
                  ? 'Chargement Flow...'
                  : 'Portrait de secours'}
              </span>
            </span>
          )}
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          {visualStyle === 'avatar_3d' && (
            <button
              type="button"
              onClick={() =>
                setCameraPreset((prev) =>
                  prev === 'front' ? 'angle' : prev === 'angle' ? 'wide' : 'front'
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700/80 bg-slate-900/90 px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
              title="Changer l'angle de caméra 3D"
            >
              <Camera className="h-3.5 w-3.5 text-sky-400" aria-hidden="true" />
              <span>
                {cameraPreset === 'front'
                  ? 'Caméra Face'
                  : cameraPreset === 'angle'
                  ? 'Caméra 3/4'
                  : 'Plan large'}
              </span>
            </button>
          )}

          <button
            type="button"
            onClick={() =>
              onChangeVisualStyle(
                visualStyle === 'portrait'
                  ? 'avatar_3d'
                  : visualStyle === 'avatar_3d'
                  ? 'flow_video'
                  : visualStyle === 'flow_video'
                  ? 'voice_only'
                  : 'portrait'
              )
            }
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700/80 bg-slate-900/90 px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            title="Changer la présentation visuelle sans couper l’audio"
          >
            {visualStyle === 'avatar_3d' ? (
              <Box className="h-3.5 w-3.5 text-sky-400" aria-hidden="true" />
            ) : (
              <Video className="h-3.5 w-3.5" aria-hidden="true" />
            )}
            <span>
              {visualStyle === 'portrait'
                ? 'Portrait'
                : visualStyle === 'avatar_3d'
                ? 'Avatar 3D'
                : visualStyle === 'flow_video'
                ? 'Flow MP4'
                : 'Voix seule'}
            </span>
          </button>

          <button
            type="button"
            onClick={onToggleMinimize}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700/80 bg-slate-900/80 px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
          >
            {isMinimized ? (
              <>
                <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Agrandir la vidéo</span>
              </>
            ) : (
              <>
                <Minimize2 className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Réduire</span>
              </>
            )}
          </button>

          {!isMinimized && (
            <button
              type="button"
              onClick={onToggleBrowserFullscreen}
              className="hidden sm:inline-flex items-center gap-1.5 rounded-lg border border-slate-700/80 bg-slate-900/80 px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
              aria-label={isBrowserFullscreen ? 'Quitter le plein écran' : 'Plein écran'}
            >
              <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{isBrowserFullscreen ? 'Quitter plein écran' : 'Plein écran'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Main visual centerpiece (hidden wrapper in avatar_3d so OrbitControls receives pointer drag across full stage) */}
      {visualStyle !== 'avatar_3d' && (
      <div className="relative z-10 flex h-[calc(100%-108px)] min-h-[260px] items-center justify-center px-4 pb-6">
        {visualStyle === 'voice_only' ? (
          <div className="flex flex-col items-center justify-center gap-4 text-center">
            <div
              className="flex h-32 w-32 items-center justify-center rounded-full border border-slate-700 bg-slate-900/90 transition-transform duration-100"
              style={{
                transform: `scale(${1 + voiceEnergy * 0.08})`,
                boxShadow:
                  state === 'speaking'
                    ? `0 0 0 ${Math.round(4 + voiceEnergy * 18)}px rgba(56, 189, 248, 0.16)`
                    : 'none',
              }}
            >
              <AudioLines className="h-12 w-12 text-sky-400" aria-hidden="true" />
            </div>
            <div>
              <p className="font-display text-base font-semibold text-white">
                {interlocutorName}
              </p>
              <p className="mt-1 text-xs text-slate-400">
                Mode audio concentré · Voix studio Charon
              </p>
            </div>
          </div>
        ) : (
          <div className="relative flex h-full max-h-[460px] items-center justify-center">
            {/* Dynamic reactive halo */}
            <div
              aria-hidden="true"
              className={`pointer-events-none absolute -inset-1.5 rounded-2xl border-2 transition-all duration-150 ${ringColorClass}`}
              style={{ opacity: ringOpacity }}
            />

            {/* Optional Flow MP4 layer with automatic fallback to photorealistic portrait */}
            {visualStyle === 'flow_video' && flowStatus !== 'fallback' && (
              <video
                key={flowVideoSrc}
                src={flowVideoSrc}
                autoPlay
                loop
                muted
                playsInline
                onCanPlay={() => setFlowStatus('active')}
                onError={() => setFlowStatus('fallback')}
                className={`relative z-10 h-full max-h-[440px] w-auto rounded-xl object-cover shadow-2xl ${
                  flowStatus === 'active' ? 'block' : 'hidden'
                }`}
              />
            )}

            {/* Preloaded Multi-Frame Reactive Portrait */}
            {(visualStyle === 'portrait' ||
              (visualStyle === 'flow_video' && flowStatus !== 'active')) && (
              <div
                className="relative h-full max-h-[440px] aspect-[3/4] overflow-hidden rounded-xl border border-white/10 bg-slate-900 shadow-2xl transition-transform duration-150 ease-out"
                style={{
                  transform: `translateY(${speakingTiltY}px) scale(${dynamicScale})`,
                }}
              >
                {!imgFailed ? (
                  <>
                    {(Object.keys(frames) as ReactionKey[]).map((key) => {
                      const isActive = activeFrame === key;
                      return (
                        <img
                          key={`${mode}-${key}`}
                          src={frames[key]}
                          alt={
                            isActive
                              ? `${interlocutorName} — ${currentStateInfo.label}`
                              : ''
                          }
                          aria-hidden={!isActive}
                          referrerPolicy="no-referrer"
                          onError={() => {
                            if (key === 'idle') setImgFailed(true);
                          }}
                          className={`absolute inset-0 h-full w-full object-cover object-top transition-opacity duration-150 ${
                            isActive ? 'opacity-100' : 'opacity-0'
                          } ${state !== 'speaking' ? 'portrait-breathe' : ''}`}
                        />
                      );
                    })}
                  </>
                ) : (
                  <div className="flex h-full w-full flex-col items-center justify-center gap-3 bg-gradient-to-br from-slate-800 to-slate-900 p-6 text-center">
                    <UserCheck className="h-12 w-12 text-sky-400" aria-hidden="true" />
                    <span className="font-display text-sm font-semibold text-white">
                      {interlocutorName}
                    </span>
                  </div>
                )}

                {/* Subtle lower contrast scrim for equalizer readability */}
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-slate-950/85 via-slate-950/35 to-transparent"
                />

                {/* Audio-reactive studio equalizer + reaction caption */}
                <div className="absolute inset-x-0 bottom-3 flex flex-col items-center gap-1.5 px-4">
                  <div className="flex items-end justify-center gap-1.5 h-7">
                    {voiceBands.map((band, idx) => {
                      const heightPx =
                        state === 'speaking'
                          ? Math.max(4, Math.round(4 + band * 22))
                          : candidateIsAudible
                          ? Math.max(4, Math.round(4 + candidateLevel * (8 + (idx % 3) * 4)))
                          : state === 'thinking'
                          ? idx % 2 === 0
                            ? 6
                            : 4
                          : 4;
                      return (
                        <span
                          key={idx}
                          className={`w-1 rounded-full transition-all duration-75 ${
                            state === 'speaking'
                              ? 'bg-sky-400'
                              : candidateIsAudible
                              ? 'bg-emerald-400'
                              : state === 'thinking'
                              ? 'bg-amber-400/75'
                              : 'bg-slate-400/50'
                          }`}
                          style={{ height: `${heightPx}px` }}
                        />
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      )}
    </div>
  );
};
