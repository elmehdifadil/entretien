import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { RectAreaLightUniformsLib } from 'three/examples/jsm/lights/RectAreaLightUniformsLib.js';
import type { InterlocutorState, InterviewMode } from '../types/interview';
import { createProceduralTextures } from '../three/proceduralTextures';
import { createStudioMaterials } from '../three/materials';
import { buildExecutiveStudioAndAvatar } from '../three/buildInterviewerRig';

export type CameraPreset = 'front' | 'angle' | 'wide';

interface Studio3DCanvasProps {
  mode: InterviewMode;
  state: InterlocutorState;
  voiceEnergy: number;
  candidateLevel?: number;
  cameraPreset?: CameraPreset;
  className?: string;
}

const CAMERA_PRESETS: Record<
  CameraPreset,
  { pos: [number, number, number]; target: [number, number, number] }
> = {
  front: { pos: [0, 1.38, 1.18], target: [0, 1.24, -0.18] },
  angle: { pos: [0.95, 1.48, 1.25], target: [0, 1.18, -0.14] },
  wide: { pos: [-1.15, 1.65, 2.05], target: [0, 1.05, -0.12] },
};

// Module-level pre-allocated scratch math helpers (zero GC inside animation loop)
const _targetPos = new THREE.Vector3();
const _targetLook = new THREE.Vector3();

function detectSoftwareWebGL(): boolean {
  try {
    const probeCanvas = document.createElement('canvas');
    const gl = probeCanvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export const Studio3DCanvas: React.FC<Studio3DCanvasProps> = ({
  mode,
  state,
  voiceEnergy,
  candidateLevel = 0,
  cameraPreset = 'front',
  className = 'h-full w-full',
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [webglError, setWebglError] = useState<string | null>(null);

  // Mutable refs read inside 60fps loop without tearing down WebGL context
  const livePropsRef = useRef({
    mode,
    state,
    voiceEnergy,
    candidateLevel,
  });
  livePropsRef.current = { mode, state, voiceEnergy, candidateLevel };

  const presetTransitionRef = useRef<{
    active: boolean;
    preset: CameraPreset;
  }>({ active: false, preset: cameraPreset });

  const lastPresetRef = useRef<CameraPreset>(cameraPreset);
  useEffect(() => {
    if (cameraPreset !== lastPresetRef.current) {
      lastPresetRef.current = cameraPreset;
      presetTransitionRef.current = { active: true, preset: cameraPreset };
    }
  }, [cameraPreset]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    let renderer: THREE.WebGLRenderer;

    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglError('WebGL2 indisponible sur cet appareil.');
      return;
    }

    const width = Math.max(300, container.clientWidth);
    const height = Math.max(240, container.clientHeight);

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const domCanvas = renderer.domElement;
    domCanvas.style.display = 'block';
    domCanvas.style.width = '100%';
    domCanvas.style.height = '100%';
    container.innerHTML = '';
    container.appendChild(domCanvas);

    const onContextLost = (e: Event) => {
      e.preventDefault();
      setWebglError('Contexte WebGL suspendu temporairement.');
    };
    const onContextRestored = () => {
      setWebglError(null);
    };
    domCanvas.addEventListener('webglcontextlost', onContextLost);
    domCanvas.addEventListener('webglcontextrestored', onContextRestored);

    // Scene & horizon-matched FogExp2
    const scene = new THREE.Scene();
    const bgHex = 0x0f172a;
    scene.background = new THREE.Color(bgHex);
    scene.fog = new THREE.FogExp2(bgHex, 0.085);

    // Studio Environment Map (RoomEnvironment + PMREMGenerator)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    // Camera & OrbitControls
    const initialPreset = CAMERA_PRESETS[cameraPreset];
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 30);
    camera.position.set(...initialPreset.pos);

    const controls = new OrbitControls(camera, domCanvas);
    controls.target.set(...initialPreset.target);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.07;
    controls.enablePan = false;
    controls.minDistance = 0.85;
    controls.maxDistance = 3.6;
    controls.minPolarAngle = Math.PI * 0.25;
    controls.maxPolarAngle = Math.PI * 0.56;
    controls.minAzimuthAngle = -Math.PI * 0.42;
    controls.maxAzimuthAngle = Math.PI * 0.42;
    controls.update();

    const onControlsStart = () => {
      presetTransitionRef.current.active = false;
    };
    controls.addEventListener('start', onControlsStart);

    // Three-point Studio Lighting + Warm/Cool Contrast
    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x1e293b, 0.85);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff1dc, 1.9);
    keyLight.position.set(2.4, 3.6, 2.8);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.camera.near = 0.5;
    keyLight.shadow.camera.far = 10;
    keyLight.shadow.camera.left = -2.6;
    keyLight.shadow.camera.right = 2.6;
    keyLight.shadow.camera.top = 2.6;
    keyLight.shadow.camera.bottom = -2.6;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.95);
    rimLight.position.set(-2.2, 2.4, -1.6);
    scene.add(rimLight);

    let rectLight: THREE.RectAreaLight | null = null;
    if (!isSoftwareGl) {
      RectAreaLightUniformsLib.init();
      rectLight = new THREE.RectAreaLight(0xfff7ed, 2.4, 1.8, 1.2);
      rectLight.position.set(-1.6, 1.9, 1.6);
      rectLight.lookAt(0, 1.2, -0.2);
      scene.add(rectLight);
    }

    // Procedural Textures, Materials, and Composite Rig
    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();
    const textures = createProceduralTextures(maxAnisotropy);
    const materials = createStudioMaterials(textures, livePropsRef.current.mode, isSoftwareGl);
    const rig = buildExecutiveStudioAndAvatar(materials);
    scene.add(rig.root);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // ResizeObserver for crisp layout adaptation
    const resizeObserver = new ResizeObserver(() => {
      if (!container) return;
      const nextW = Math.max(300, container.clientWidth);
      const nextH = Math.max(240, container.clientHeight);
      camera.aspect = nextW / nextH;
      camera.updateProjectionMatrix();
      renderer.setSize(nextW, nextH);
    });
    resizeObserver.observe(container);

    // Animation State
    let frameId = 0;
    let disposed = false;
    let prevTime = performance.now();
    let elapsed = 0;
    let currentJaw = 0;
    let currentHeadX = 0;
    let currentHeadY = 0;
    let currentHeadZ = 0;
    let currentEyeX = 0;
    let currentEyeY = 0;
    let nextBlinkAt = 2.6;
    let appliedMode: InterviewMode = livePropsRef.current.mode;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || !gl.fenceSync) {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const syncState = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (syncState === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const tick = () => {
      if (disposed) return;
      const now = performance.now();
      const dt = Math.min(0.05, (now - prevTime) / 1000);
      prevTime = now;
      elapsed += dt;

      const {
        mode: activeMode,
        state: activeState,
        voiceEnergy: activeVoice,
        candidateLevel: activeMic,
      } = livePropsRef.current;

      // Update attire colors dynamically when switching between Recruiter and Coach
      if (activeMode !== appliedMode) {
        appliedMode = activeMode;
        const isRec = activeMode === 'recruiter';
        materials.jacket.color.setHex(isRec ? 0x262b34 : 0x1b2d4b);
        materials.shirt.color.setHex(isRec ? 0xf4f6f9 : 0x475569);
        materials.accentCloth.color.setHex(isRec ? 0x1d3b72 : 0x2563eb);
        materials.iris.color.setHex(isRec ? 0x3a2618 : 0x38586f);
      }

      // 1. Damped Camera Preset Transition
      if (presetTransitionRef.current.active) {
        const cfg = CAMERA_PRESETS[presetTransitionRef.current.preset];
        _targetPos.set(...cfg.pos);
        _targetLook.set(...cfg.target);
        const alpha = 1 - Math.exp(-5.5 * dt);
        camera.position.lerp(_targetPos, alpha);
        controls.target.lerp(_targetLook, alpha);
        if (
          camera.position.distanceToSquared(_targetPos) < 0.0004 &&
          controls.target.distanceToSquared(_targetLook) < 0.0004
        ) {
          camera.position.copy(_targetPos);
          controls.target.copy(_targetLook);
          presetTransitionRef.current.active = false;
        }
      }
      controls.update();

      // 2. Subtle Breathing
      rig.torsoGroup.position.y = 0.64 + Math.sin(elapsed * 1.55) * 0.0035;

      // 3. Expressive Interlocutor Kinematics & Jaw Articulation
      let targetJaw = 0;
      let targetHeadX = Math.sin(elapsed * 0.7) * 0.012;
      let targetHeadY = Math.sin(elapsed * 0.45) * 0.02;
      let targetHeadZ = 0;
      let targetEyeX = 0;
      let targetEyeY = 0;

      if (activeState === 'speaking') {
        const syllableWave = 0.55 + 0.45 * Math.sin(elapsed * 19.0);
        targetJaw = Math.min(0.36, activeVoice * 0.48 * syllableWave + 0.04);
        targetHeadX = -0.025 + Math.sin(elapsed * 3.1) * (0.02 + activeVoice * 0.04);
        targetHeadY = Math.sin(elapsed * 1.7) * 0.055;
        targetHeadZ = Math.sin(elapsed * 1.2) * 0.025;
        materials.ledAccent.color.setHex(0x38bdf8);
        materials.ledAccent.emissive.setHex(0x38bdf8);
      } else if (activeState === 'thinking') {
        targetHeadX = -0.055;
        targetHeadY = -0.13;
        targetHeadZ = 0.065;
        targetEyeX = -0.0022;
        targetEyeY = 0.0018;
        materials.ledAccent.color.setHex(0xf59e0b);
        materials.ledAccent.emissive.setHex(0xf59e0b);
      } else if (activeState === 'listening') {
        const nod = activeMic > 0.08 ? Math.sin(elapsed * 4.2) * 0.035 : 0;
        targetHeadX = 0.018 + nod;
        targetHeadZ = activeMic > 0.08 ? -0.028 : -0.012;
        materials.ledAccent.color.setHex(0x10b981);
        materials.ledAccent.emissive.setHex(0x10b981);
      } else {
        materials.ledAccent.color.setHex(0x64748b);
        materials.ledAccent.emissive.setHex(0x64748b);
      }

      const jawAlpha = 1 - Math.exp(-22 * dt);
      const headAlpha = 1 - Math.exp(-6.5 * dt);
      currentJaw = THREE.MathUtils.lerp(currentJaw, targetJaw, jawAlpha);
      currentHeadX = THREE.MathUtils.lerp(currentHeadX, targetHeadX, headAlpha);
      currentHeadY = THREE.MathUtils.lerp(currentHeadY, targetHeadY, headAlpha);
      currentHeadZ = THREE.MathUtils.lerp(currentHeadZ, targetHeadZ, headAlpha);
      currentEyeX = THREE.MathUtils.lerp(currentEyeX, targetEyeX, headAlpha);
      currentEyeY = THREE.MathUtils.lerp(currentEyeY, targetEyeY, headAlpha);

      rig.jawPivot.rotation.x = currentJaw;
      rig.headPivot.rotation.set(currentHeadX, currentHeadY, currentHeadZ);
      rig.leftIrisGroup.position.set(currentEyeX, currentEyeY, 0);
      rig.rightIrisGroup.position.set(currentEyeX, currentEyeY, 0);

      // 4. Natural Periodic Blinking
      let blinkAmount = 0;
      if (elapsed >= nextBlinkAt) {
        const blinkPhase = elapsed - nextBlinkAt;
        if (blinkPhase < 0.16) {
          blinkAmount = Math.sin((blinkPhase / 0.16) * Math.PI);
        } else {
          nextBlinkAt = elapsed + 2.8 + Math.random() * 2.4;
        }
      }
      const lidRot = -0.75 + blinkAmount * 0.92;
      rig.leftEyelid.rotation.x = lidRot;
      rig.rightEyelid.rotation.x = lidRot;

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      controls.removeEventListener('start', onControlsStart);
      controls.dispose();
      domCanvas.removeEventListener('webglcontextlost', onContextLost);
      domCanvas.removeEventListener('webglcontextrestored', onContextRestored);
      rig.dispose();
      materials.dispose();
      textures.dispose();
      envTarget.dispose();
      renderer.dispose();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (webglError) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-slate-900 text-slate-200 p-6 text-center ${className}`}
      >
        <p className="text-sm font-semibold">{webglError}</p>
        <p className="mt-1 text-xs text-slate-400">
          Le mode Portrait interactif reste disponible sans interruption.
        </p>
      </div>
    );
  }

  return <div ref={mountRef} className={className} />;
};
