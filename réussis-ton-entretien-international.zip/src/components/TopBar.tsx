import React from 'react';

export type AppView = 'setup' | 'studio3d' | 'live' | 'report' | 'history';

interface TopBarProps {
  activeView: AppView;
  hasReport: boolean;
  historyCount: number;
  isLiveActive: boolean;
  onNavigate: (view: AppView) => void;
  onPrimaryAction: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeView,
  hasReport,
  historyCount,
  isLiveActive,
  onNavigate,
  onPrimaryAction,
}) => {
  return (
    <header className="no-print sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-8 px-4 py-3.5 sm:px-6">
        {/* Zone 1: Single-line brand wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('setup')}
          className="font-display text-left text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-blue-700 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded"
        >
          Entretien International
        </button>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav
          aria-label="Navigation principale"
          className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600"
        >
          <button
            type="button"
            onClick={() => onNavigate('setup')}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
              activeView === 'setup'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Préparation
          </button>

          <button
            type="button"
            onClick={() => onNavigate('studio3d')}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
              activeView === 'studio3d'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Studio 3D
          </button>

          <button
            type="button"
            onClick={() => onNavigate('live')}
            disabled={!isLiveActive}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
              activeView === 'live'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : isLiveActive
                ? 'border-transparent hover:text-slate-900'
                : 'border-transparent text-slate-400 cursor-not-allowed'
            }`}
          >
            Simulation
          </button>

          <button
            type="button"
            onClick={() => onNavigate('report')}
            disabled={!hasReport}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
              activeView === 'report'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : hasReport
                ? 'border-transparent hover:text-slate-900'
                : 'border-transparent text-slate-400 cursor-not-allowed'
            }`}
          >
            Bilan
          </button>

          <button
            type="button"
            onClick={() => onNavigate('history')}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
              activeView === 'history'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Historique ({historyCount})
          </button>
        </nav>

        {/* Zone 3: 1 primary CTA */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onPrimaryAction}
            className="whitespace-nowrap shrink-0 rounded-lg bg-blue-700 px-4 py-2 text-xs sm:text-sm font-semibold text-white hover:bg-blue-800 active:scale-[0.99] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 min-h-[40px]"
          >
            {isLiveActive
              ? activeView === 'live'
                ? 'Terminer et bilan'
                : 'Revenir à l’appel'
              : 'Démarrer l’entretien'}
          </button>
        </div>
      </div>

      {/* Compact mobile navigation row */}
      <div className="flex md:hidden items-center gap-4 overflow-x-auto border-t border-slate-100 px-4 py-2 text-xs font-medium text-slate-600">
        <button
          type="button"
          onClick={() => onNavigate('setup')}
          className={`whitespace-nowrap shrink-0 py-1 ${
            activeView === 'setup' ? 'text-blue-700 font-semibold' : ''
          }`}
        >
          Préparation
        </button>
        <button
          type="button"
          onClick={() => onNavigate('studio3d')}
          className={`whitespace-nowrap shrink-0 py-1 ${
            activeView === 'studio3d' ? 'text-blue-700 font-semibold' : ''
          }`}
        >
          Studio 3D
        </button>
        {isLiveActive && (
          <button
            type="button"
            onClick={() => onNavigate('live')}
            className={`whitespace-nowrap shrink-0 py-1 ${
              activeView === 'live' ? 'text-blue-700 font-semibold' : ''
            }`}
          >
            Simulation
          </button>
        )}
        {hasReport && (
          <button
            type="button"
            onClick={() => onNavigate('report')}
            className={`whitespace-nowrap shrink-0 py-1 ${
              activeView === 'report' ? 'text-blue-700 font-semibold' : ''
            }`}
          >
            Bilan
          </button>
        )}
        <button
          type="button"
          onClick={() => onNavigate('history')}
          className={`whitespace-nowrap shrink-0 py-1 ${
            activeView === 'history' ? 'text-blue-700 font-semibold' : ''
          }`}
        >
          Historique ({historyCount})
        </button>
      </div>
    </header>
  );
};
