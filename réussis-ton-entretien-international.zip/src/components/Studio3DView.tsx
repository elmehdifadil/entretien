import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Camera,
  ChevronDown,
  ChevronUp,
  Ear,
  Play,
  Sparkles,
  UserCheck,
  Volume2,
} from 'lucide-react';
import type { InterlocutorState, InterviewMode } from '../types/interview';
import { Studio3DCanvas, type CameraPreset } from './Studio3DCanvas';

interface Studio3DViewProps {
  mode: InterviewMode;
  onChangeMode: (mode: InterviewMode) => void;
  onStartInterviewWith3D: () => void;
  onBackToSetup: () => void;
}

export const Studio3DView: React.FC<Studio3DViewProps> = ({
  mode,
  onChangeMode,
  onStartInterviewWith3D,
  onBackToSetup,
}) => {
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('front');
  const [previewState, setPreviewState] = useState<InterlocutorState>('listening');
  const [simulatedVoice, setSimulatedVoice] = useState(0);
  const [dockCollapsed, setDockCollapsed] = useState(false);

  // Keyboard shortcut 'H' to hide/show bottom control dock
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.key.toLowerCase() === 'h' &&
        !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement)
      ) {
        setDockCollapsed((c) => !c);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // Synthetic voice envelope when previewing 'speaking' state in the 3D studio
  useEffect(() => {
    if (previewState !== 'speaking') {
      setSimulatedVoice(0);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const step = () => {
      const t = (performance.now() - start) / 1000;
      const env = 0.25 + 0.5 * Math.abs(Math.sin(t * 4.8)) * Math.abs(Math.cos(t * 2.1));
      setSimulatedVoice(env);
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [previewState]);

  const stateLabels: Record<InterlocutorState, string> = {
    idle: 'Prêt',
    connecting: 'Connexion',
    listening: 'Écoute attentive',
    thinking: 'Réflexion',
    speaking: 'Parole active',
  };

  return (
    <div className="relative h-[calc(100vh-65px)] w-full overflow-hidden bg-slate-950 select-none">
      {/* Unobstructed Full-Bleed Three.js Canvas */}
      <Studio3DCanvas
        mode={mode}
        state={previewState}
        voiceEnergy={simulatedVoice}
        candidateLevel={previewState === 'listening' ? 0.12 : 0}
        cameraPreset={cameraPreset}
        className="h-full w-full"
      />

      {/* Minimal Top-Left Spec Bar (Solid/rgba surface — NO backdrop-filter over WebGL) */}
      <div
        className="pointer-events-auto absolute left-4 top-4 z-10 flex flex-wrap items-center gap-3 rounded-xl border border-slate-700/80 px-3.5 py-2.5 text-white"
        style={{ backgroundColor: 'rgba(15, 23, 42, 0.92)' }}
      >
        <button
          type="button"
          onClick={onBackToSetup}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-300 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Préparation</span>
        </button>
        <span className="text-slate-600" aria-hidden="true">
          |
        </span>
        <span className="font-display text-xs sm:text-sm font-semibold text-white">
          Studio 3D · {mode === 'recruiter' ? 'Karim (Recruteur)' : 'Marc (Coach)'}
        </span>
        <span className="text-xs text-sky-300">{stateLabels[previewState]}</span>
      </div>

      {/* Top-Right Primary Action to launch interview with 3D avatar */}
      <div className="pointer-events-auto absolute right-4 top-4 z-10">
        <button
          type="button"
          onClick={onStartInterviewWith3D}
          className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white hover:bg-blue-700 transition-colors min-h-[40px]"
        >
          <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
          <span>Utiliser cet avatar 3D</span>
        </button>
      </div>

      {/* Collapsible Bottom Control Dock (Zero side-panel clutter, rgba without backdrop-filter) */}
      <div
        className="pointer-events-auto absolute left-1/2 z-20 transition-transform duration-200"
        style={{
          bottom: '20px',
          transform: dockCollapsed
            ? 'translate(-50%, calc(100% - 34px))'
            : 'translate(-50%, 0)',
          width: 'min(900px, 94vw)',
        }}
      >
        <div className="flex justify-center">
          <button
            type="button"
            onClick={() => setDockCollapsed((c) => !c)}
            className="inline-flex items-center gap-1.5 rounded-t-xl border border-b-0 border-slate-700/90 px-4 py-1.5 text-xs font-medium text-slate-200 hover:text-white transition-colors"
            style={{ backgroundColor: 'rgba(15, 23, 42, 0.94)' }}
          >
            {dockCollapsed ? (
              <>
                <ChevronUp className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Afficher les contrôles (H)</span>
              </>
            ) : (
              <>
                <ChevronDown className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Masquer les contrôles (H)</span>
              </>
            )}
          </button>
        </div>

        <div
          className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-700/90 px-4 py-3 text-white shadow-2xl"
          style={{ backgroundColor: 'rgba(15, 23, 42, 0.94)' }}
        >
          {/* Role Style Toggle */}
          <div className="flex items-center gap-1.5 rounded-lg bg-slate-800/90 p-1">
            <button
              type="button"
              onClick={() => onChangeMode('recruiter')}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                mode === 'recruiter'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <UserCheck className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Recruteur</span>
            </button>
            <button
              type="button"
              onClick={() => onChangeMode('coach')}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                mode === 'coach'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <UserCheck className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Coach</span>
            </button>
          </div>

          {/* Camera Presets */}
          <div className="flex items-center gap-1.5">
            <Camera className="h-3.5 w-3.5 text-slate-400 mr-1 hidden sm:inline" aria-hidden="true" />
            {(
              [
                { id: 'front' as CameraPreset, label: 'Face' },
                { id: 'angle' as CameraPreset, label: 'Bureau 3/4' },
                { id: 'wide' as CameraPreset, label: 'Plan large' },
              ] as const
            ).map((cam) => (
              <button
                key={cam.id}
                type="button"
                onClick={() => setCameraPreset(cam.id)}
                className={`rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                  cameraPreset === cam.id
                    ? 'bg-slate-700 text-white border border-slate-500'
                    : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800 border border-transparent'
                }`}
              >
                {cam.label}
              </button>
            ))}
          </div>

          {/* Reaction Preview Triggers */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setPreviewState('listening')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                previewState === 'listening'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Ear className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Écoute</span>
            </button>
            <button
              type="button"
              onClick={() => setPreviewState('thinking')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                previewState === 'thinking'
                  ? 'bg-amber-600 text-white'
                  : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Réflexion</span>
            </button>
            <button
              type="button"
              onClick={() => setPreviewState('speaking')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                previewState === 'speaking'
                  ? 'bg-sky-600 text-white'
                  : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Parole</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
