import React from 'react';
import { ArrowRight, Calendar, Trash2 } from 'lucide-react';
import { LANGUAGE_OPTIONS, type SavedSession } from '../types/interview';
import { formatDuration } from '../utils/storage';

interface HistoryViewProps {
  sessions: SavedSession[];
  onOpenSession: (session: SavedSession) => void;
  onDeleteSession: (id: string) => void;
  onClearAll: () => void;
  onStartNew: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  sessions,
  onOpenSession,
  onDeleteSession,
  onClearAll,
  onStartNew,
}) => {
  return (
    <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:py-10">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Historique des simulations
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Vos derniers bilans enregistrés localement sur ce navigateur pour suivre votre
            progression.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {sessions.length > 0 && (
            <button
              type="button"
              onClick={onClearAll}
              className="rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Tout effacer
            </button>
          )}
          <button
            type="button"
            onClick={onStartNew}
            className="rounded-lg bg-blue-700 px-4 py-2 text-xs sm:text-sm font-semibold text-white hover:bg-blue-800 transition-colors"
          >
            Nouvelle simulation
          </button>
        </div>
      </div>

      {sessions.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center">
          <Calendar className="mx-auto h-8 w-8 text-slate-400" aria-hidden="true" />
          <h2 className="font-display mt-3 text-base font-bold text-slate-900">
            Aucune simulation enregistrée
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Lancez votre premier entretien international pour obtenir un diagnostic en 5 axes.
          </p>
          <button
            type="button"
            onClick={onStartNew}
            className="mt-5 inline-flex items-center gap-2 rounded-lg bg-blue-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 transition-colors"
          >
            <span>Configurer un entretien</span>
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      ) : (
        <div className="mt-6 divide-y divide-slate-200 rounded-2xl border border-slate-200 bg-white overflow-hidden">
          {sessions.map((session) => {
            const langLabel =
              LANGUAGE_OPTIONS.find((l) => l.code === session.config.language)?.label ||
              session.config.language;
            return (
              <div
                key={session.id}
                className="flex flex-wrap items-center justify-between gap-4 p-5 hover:bg-slate-50/70 transition-colors"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                    <span>{new Date(session.dateIso).toLocaleDateString('fr-FR')}</span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {session.config.mode === 'recruiter' ? 'Recruteur' : 'Coach'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{langLabel}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{formatDuration(session.durationSeconds)}</span>
                  </div>
                  <h3 className="font-display mt-1 text-base font-semibold text-slate-900 truncate">
                    {session.config.role} — {session.config.country}
                  </h3>
                  {session.report && (
                    <p className="mt-0.5 text-xs text-slate-600 line-clamp-1">
                      {session.report.readinessLevel}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-4 shrink-0">
                  {session.report && (
                    <div className="text-right">
                      <span className="font-mono text-xl font-bold text-slate-900">
                        {session.report.overallScore}
                      </span>
                      <span className="font-mono text-xs text-slate-500"> / 100</span>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => onOpenSession(session)}
                    className="rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 transition-colors"
                  >
                    Consulter le bilan
                  </button>

                  <button
                    type="button"
                    onClick={() => onDeleteSession(session.id)}
                    aria-label="Supprimer cette simulation"
                    className="rounded-lg p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </main>
  );
};
