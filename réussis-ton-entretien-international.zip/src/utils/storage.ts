import { LANGUAGE_OPTIONS, type DiagnosticReport, type SavedSession } from '../types/interview';

const STORAGE_KEY = 'entretien_international_sessions_v1';

export function loadSavedSessions(): SavedSession[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveSession(session: SavedSession): SavedSession[] {
  const existing = loadSavedSessions().filter((s) => s.id !== session.id);
  const next = [session, ...existing].slice(0, 20);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // ignore storage quota errors
  }
  return next;
}

export function deleteSession(id: string): SavedSession[] {
  const next = loadSavedSessions().filter((s) => s.id !== id);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // ignore
  }
  return next;
}

export function clearAllSessions(): SavedSession[] {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
  return [];
}

export function formatDuration(seconds: number): string {
  const mins = Math.floor(Math.max(0, seconds) / 60);
  const secs = Math.floor(Math.max(0, seconds) % 60);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function buildReportDownloadText(session: {
  config: SavedSession['config'];
  report: DiagnosticReport;
  transcript: SavedSession['transcript'];
}): string {
  const { config, report, transcript } = session;
  const langLabel =
    LANGUAGE_OPTIONS.find((l) => l.code === config.language)?.label || config.language;

  const lines: string[] = [
    'RÉUSSIS TON ENTRETIEN INTERNATIONAL — DIAGNOSTIC FINAL',
    '====================================================',
    `Date : ${new Date(report.generatedAt).toLocaleString('fr-FR')}`,
    `Mode : ${config.mode === 'recruiter' ? 'Recruteur' : 'Coach'}`,
    `Poste visé : ${config.role}`,
    `Pays de destination : ${config.country}`,
    `Langue : ${langLabel}`,
    `Score global : ${report.overallScore} / 100 (${report.readinessLevel})`,
    '',
    'SYNTHÈSE',
    '--------',
    report.executiveSummary,
    '',
    'ÉVALUATION SUR 5 AXES',
    '---------------------',
    ...report.axes.flatMap((axis, idx) => [
      `${idx + 1}. ${axis.label} : ${axis.score} / ${axis.maxScore}`,
      `   Observation : ${axis.observation}`,
      `   Conseil : ${axis.advice}`,
      '',
    ]),
    'POINTS FORTS',
    '------------',
    ...report.strengths.map((s) => `- ${s}`),
    '',
    "AXES D'AMÉLIORATION",
    '-------------------',
    ...report.improvements.map((i) => `- ${i}`),
    '',
    'ATELIER DE REFORMULATION',
    '------------------------',
    ...report.reformulations.flatMap((r, idx) => [
      `Exemple ${idx + 1} :`,
      `  Ce que vous avez dit : "${r.original}"`,
      `  Formulation recommandée : "${r.improved}"`,
      `  Pourquoi : ${r.rationale}`,
      '',
    ]),
    'PROCHAINES ÉTAPES',
    '-----------------',
    ...report.nextSteps.map((n, idx) => `${idx + 1}. ${n}`),
    '',
    'TRANSCRIPTION DE LA SESSION',
    '---------------------------',
    ...transcript.map(
      (t) =>
        `[${t.timestamp}] ${t.speaker === 'candidate' ? 'Candidat' : 'Interlocuteur'} : ${t.text}`
    ),
  ];

  return lines.join('\n');
}
