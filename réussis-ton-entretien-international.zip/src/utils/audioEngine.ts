export function pcm16ToBase64(int16: Int16Array): string {
  const bytes = new Uint8Array(int16.buffer, int16.byteOffset, int16.byteLength);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const slice = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...slice);
  }
  return btoa(binary);
}

export function base64ToInt16(base64: string): Int16Array {
  const binary = atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new Int16Array(bytes.buffer);
}

export function downsampleTo16k(input: Float32Array, sourceRate: number): Float32Array {
  if (sourceRate === 16000) return input;
  const ratio = sourceRate / 16000;
  const outputLength = Math.floor(input.length / ratio);
  const output = new Float32Array(outputLength);
  for (let i = 0; i < outputLength; i++) {
    const pos = i * ratio;
    const idx = Math.floor(pos);
    const frac = pos - idx;
    const nextIdx = Math.min(idx + 1, input.length - 1);
    output[i] = input[idx] * (1 - frac) + input[nextIdx] * frac;
  }
  return output;
}

export class PcmPlaybackQueue {
  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private nextStartTime = 0;
  private activeSources = new Set<AudioBufferSourceNode>();
  private lastEndTimestamp = 0;
  private currentAudioElement: HTMLAudioElement | null = null;
  private freqBuffer = new Uint8Array(32);

  public init(): void {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx({ sampleRate: 24000 });
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 64;
      this.analyser.smoothingTimeConstant = 0.72;
      this.analyser.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
  }

  public enqueuePcm24k(base64Pcm: string, onPlaybackEnd?: () => void): void {
    this.init();
    if (!this.ctx || !this.analyser) return;

    const int16 = base64ToInt16(base64Pcm);
    if (int16.length === 0) return;

    const float32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) {
      float32[i] = int16[i] / 32768;
    }

    const buffer = this.ctx.createBuffer(1, float32.length, 24000);
    buffer.copyToChannel(float32, 0);

    const source = this.ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(this.analyser);

    // 55ms lead buffer for jitter resilience (V14 stabilization)
    const now = this.ctx.currentTime;
    const startAt = Math.max(now + 0.055, this.nextStartTime);
    this.nextStartTime = startAt + buffer.duration;
    this.lastEndTimestamp = performance.now() + (startAt - now + buffer.duration) * 1000;

    this.activeSources.add(source);
    source.onended = () => {
      this.activeSources.delete(source);
      if (this.activeSources.size === 0 && onPlaybackEnd) {
        onPlaybackEnd();
      }
    };

    source.start(startAt);
  }

  public async playWavBase64(base64Wav: string): Promise<void> {
    this.clear();
    this.init();
    const binary = atob(base64Wav);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: 'audio/wav' });
    const url = URL.createObjectURL(blob);

    return new Promise((resolve) => {
      const audio = new Audio(url);
      this.currentAudioElement = audio;
      this.lastEndTimestamp = performance.now() + 60000;

      if (this.ctx && this.analyser) {
        try {
          const mediaSource = this.ctx.createMediaElementSource(audio);
          mediaSource.connect(this.analyser);
        } catch {
          // fallback if createMediaElementSource fails
        }
      }

      const cleanup = () => {
        this.lastEndTimestamp = performance.now();
        URL.revokeObjectURL(url);
        if (this.currentAudioElement === audio) {
          this.currentAudioElement = null;
        }
        resolve();
      };

      audio.onended = cleanup;
      audio.onerror = cleanup;
      void audio.play().catch(cleanup);
    });
  }

  public isPlaying(tailGuardMs = 220): boolean {
    if (this.activeSources.size > 0) return true;
    if (this.currentAudioElement && !this.currentAudioElement.paused) return true;
    return performance.now() < this.lastEndTimestamp + tailGuardMs;
  }

  public getEnergy(): { rms: number; bands: number[] } {
    if (!this.analyser || !this.isPlaying(50)) {
      return { rms: 0, bands: [0, 0, 0, 0, 0, 0, 0, 0] };
    }
    this.analyser.getByteFrequencyData(this.freqBuffer);
    let sum = 0;
    const bands: number[] = [];
    const step = Math.floor(this.freqBuffer.length / 8);
    for (let b = 0; b < 8; b++) {
      let bandSum = 0;
      for (let j = 0; j < step; j++) {
        const val = this.freqBuffer[b * step + j] / 255;
        bandSum += val;
        sum += val;
      }
      bands.push(Math.min(1, bandSum / step));
    }
    const rms = Math.min(1, (sum / this.freqBuffer.length) * 1.45);
    return { rms, bands };
  }

  public clear(): void {
    for (const src of this.activeSources) {
      try {
        src.stop();
      } catch {
        // ignore already stopped
      }
    }
    this.activeSources.clear();
    if (this.currentAudioElement) {
      this.currentAudioElement.pause();
      this.currentAudioElement = null;
    }
    if (this.ctx) {
      this.nextStartTime = this.ctx.currentTime;
    }
    this.lastEndTimestamp = 0;
  }

  public destroy(): void {
    this.clear();
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
      this.analyser = null;
    }
  }
}

export interface MicCaptureController {
  stop: () => void;
}

const TARGET_BLOCK_SAMPLES = 640; // 40ms @ 16kHz (V14 stabilized chunk size)

export async function startMicCapture(options: {
  onPcm40ms: (base64Pcm: string) => void;
  onLevel: (level: number) => void;
  shouldGate: () => boolean;
}): Promise<MicCaptureController> {
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
      channelCount: 1,
    },
  });

  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AudioCtx({ sampleRate: 16000 });
  if (ctx.state === 'suspended') {
    await ctx.resume();
  }

  const source = ctx.createMediaStreamSource(stream);
  const processor = ctx.createScriptProcessor(1024, 1, 1);
  const silentGain = ctx.createGain();
  silentGain.gain.value = 0;

  let pending = new Float32Array(0);

  processor.onaudioprocess = (event) => {
    const raw = event.inputBuffer.getChannelData(0);
    const resampled = downsampleTo16k(raw, ctx.sampleRate);

    // Compute live mic meter RMS
    let sumSq = 0;
    for (let i = 0; i < resampled.length; i++) {
      sumSq += resampled[i] * resampled[i];
    }
    const rms = Math.sqrt(sumSq / Math.max(1, resampled.length));
    options.onLevel(Math.min(1, rms * 5.5));

    if (options.shouldGate()) {
      pending = new Float32Array(0);
      return;
    }

    const merged = new Float32Array(pending.length + resampled.length);
    merged.set(pending, 0);
    merged.set(resampled, pending.length);
    pending = merged;

    while (pending.length >= TARGET_BLOCK_SAMPLES) {
      const block = pending.subarray(0, TARGET_BLOCK_SAMPLES);
      pending = pending.subarray(TARGET_BLOCK_SAMPLES);

      const int16 = new Int16Array(TARGET_BLOCK_SAMPLES);
      for (let i = 0; i < TARGET_BLOCK_SAMPLES; i++) {
        const clamped = Math.max(-1, Math.min(1, block[i]));
        int16[i] = clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff;
      }
      options.onPcm40ms(pcm16ToBase64(int16));
    }
  };

  source.connect(processor);
  processor.connect(silentGain);
  silentGain.connect(ctx.destination);

  return {
    stop: () => {
      try {
        processor.disconnect();
        source.disconnect();
        silentGain.disconnect();
      } catch {
        // ignore
      }
      stream.getTracks().forEach((track) => track.stop());
      void ctx.close();
    },
  };
}
