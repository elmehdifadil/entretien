export type InterviewMode = 'recruiter' | 'coach';

export type LanguageCode = 'fr' | 'en' | 'ary' | 'ar' | 'es' | 'de';

export type ExperienceLevel = 'junior' | 'mid' | 'senior' | 'executive';

export type InterviewFocus =
  | 'comprehensive'
  | 'behavioral_star'
  | 'technical_role'
  | 'cultural_negotiation';

export type InteractionChannel = 'live_voice' | 'text_voice';

export type VisualStyle = 'portrait' | 'avatar_3d' | 'flow_video' | 'voice_only';

export type InterlocutorState = 'idle' | 'connecting' | 'listening' | 'thinking' | 'speaking';

export interface InterviewConfig {
  mode: InterviewMode;
  role: string;
  country: string;
  language: LanguageCode;
  experienceLevel: ExperienceLevel;
  focus: InterviewFocus;
  jobDescription: string;
  antiEchoProtection: boolean;
  allowInterruptions: boolean;
  channel: InteractionChannel;
  visualStyle: VisualStyle;
}

export interface TranscriptEntry {
  id: string;
  speaker: 'candidate' | 'interviewer';
  text: string;
  timestamp: string;
  elapsedSeconds: number;
}

export interface CulturalBrief {
  culturalCodes: string[];
  expectedThemes: string[];
  smartQuestions: string[];
  openingTip: string;
}

export interface DiagnosticAxis {
  id: string;
  label: string;
  score: number;
  maxScore: number;
  observation: string;
  advice: string;
}

export interface ReformulationItem {
  original: string;
  improved: string;
  rationale: string;
}

export interface DiagnosticReport {
  overallScore: number;
  readinessLevel: string;
  executiveSummary: string;
  axes: DiagnosticAxis[];
  strengths: string[];
  improvements: string[];
  reformulations: ReformulationItem[];
  nextSteps: string[];
  generatedAt: string;
  language: LanguageCode;
}

export interface SavedSession {
  id: string;
  dateIso: string;
  config: InterviewConfig;
  transcript: TranscriptEntry[];
  report: DiagnosticReport | null;
  durationSeconds: number;
}

export const LANGUAGE_OPTIONS: Array<{
  code: LanguageCode;
  label: string;
  nativeLabel: string;
  ttsLocale: string;
}> = [
  { code: 'fr', label: 'Français', nativeLabel: 'Français', ttsLocale: 'fr-FR' },
  { code: 'en', label: 'Anglais', nativeLabel: 'English', ttsLocale: 'en-US' },
  { code: 'ary', label: 'Darija marocaine', nativeLabel: 'الدارجة المغربية', ttsLocale: 'ar-MA' },
  { code: 'ar', label: 'Arabe standard', nativeLabel: 'العربية الفصحى', ttsLocale: 'ar-SA' },
  { code: 'es', label: 'Espagnol', nativeLabel: 'Español', ttsLocale: 'es-ES' },
  { code: 'de', label: 'Allemand', nativeLabel: 'Deutsch', ttsLocale: 'de-DE' },
];

export const POPULAR_COUNTRIES: string[] = [
  'France',
  'Canada',
  'Allemagne',
  'Royaume-Uni',
  'Suisse',
  'États-Unis',
  'Belgique',
  'Luxembourg',
  'Émirats Arabes Unis',
  'Espagne',
  'Pays-Bas',
  'Maroc',
];

export const ROLE_PRESETS: Array<{
  role: string;
  country: string;
  focus: InterviewFocus;
  experienceLevel: ExperienceLevel;
  summary: string;
}> = [
  {
    role: 'Ingénieur Logiciel Full-Stack',
    country: 'Canada',
    focus: 'technical_role',
    experienceLevel: 'mid',
    summary: 'Architecture, scalabilité, travail en équipe agile et impact produit.',
  },
  {
    role: 'Chef de Projet Digital / Product Manager',
    country: 'France',
    focus: 'behavioral_star',
    experienceLevel: 'senior',
    summary: 'Priorisation, alignement parties prenantes, gestion de crise (STAR).',
  },
  {
    role: 'Business Developer / Export Manager',
    country: 'Allemagne',
    focus: 'cultural_negotiation',
    experienceLevel: 'mid',
    summary: 'Prospection B2B, rigueur commerciale, négociation interculturelle.',
  },
  {
    role: 'Analyste Financier / Contrôleur de Gestion',
    country: 'Suisse',
    focus: 'comprehensive',
    experienceLevel: 'senior',
    summary: 'Précision analytique, reporting exécutif, éthique et fiabilité.',
  },
];

export const SESSION_DURATION_SECONDS = 8 * 60; // 8 minutes limit preserved
