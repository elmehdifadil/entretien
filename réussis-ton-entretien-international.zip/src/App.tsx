import { useCallback, useState } from 'react';
import { TopBar, type AppView } from './components/TopBar';
import { SetupWorkspace } from './components/SetupWorkspace';
import { Studio3DView } from './components/Studio3DView';
import { LiveCallView } from './components/LiveCallView';
import { DiagnosticReportView } from './components/DiagnosticReportView';
import { HistoryView } from './components/HistoryView';
import {
  clearAllSessions,
  deleteSession,
  loadSavedSessions,
  saveSession,
} from './utils/storage';
import type {
  DiagnosticReport,
  InterviewConfig,
  SavedSession,
  TranscriptEntry,
} from './types/interview';

const DEFAULT_CONFIG: InterviewConfig = {
  mode: 'recruiter',
  role: 'Chef de Projet Digital',
  country: 'Canada',
  language: 'fr',
  experienceLevel: 'mid',
  focus: 'comprehensive',
  jobDescription: '',
  antiEchoProtection: true,
  allowInterruptions: false,
  channel: 'live_voice',
  visualStyle: 'portrait',
};

export default function App() {
  const [view, setView] = useState<AppView>('setup');
  const [config, setConfig] = useState<InterviewConfig>(DEFAULT_CONFIG);
  const [activeSessionConfig, setActiveSessionConfig] = useState<InterviewConfig>(DEFAULT_CONFIG);
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [transcript, setTranscript] = useState<TranscriptEntry[]>([]);
  const [durationSeconds, setDurationSeconds] = useState(0);

  const [report, setReport] = useState<DiagnosticReport | null>(null);
  const [reportLoading, setReportLoading] = useState(false);
  const [reportError, setReportError] = useState<string | null>(null);

  const [history, setHistory] = useState<SavedSession[]>(() => loadSavedSessions());

  const generateDiagnostic = useCallback(
    async (
      sessionConfig: InterviewConfig,
      sessionTranscript: TranscriptEntry[],
      sessionDuration: number
    ) => {
      const hasCandidateTurns = sessionTranscript.some(
        (t) => t.speaker === 'candidate' && t.text.trim().length > 0
      );

      if (!hasCandidateTurns) {
        setReport(null);
        setReportLoading(false);
        setReportError(
          "Aucune prise de parole du candidat n'a été enregistrée durant la session. Le diagnostic nécessite au moins une réponse."
        );
        return;
      }

      setReportLoading(true);
      setReportError(null);
      setReport(null);

      try {
        const res = await fetch('/api/report', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            config: sessionConfig,
            transcript: sessionTranscript,
          }),
        });
        const data = await res.json();
        if (!res.ok || !data.report) {
          throw new Error(data.error || 'Impossible de générer le bilan.');
        }

        const generatedReport = data.report as DiagnosticReport;
        setReport(generatedReport);

        const saved: SavedSession = {
          id: `session-${Date.now()}`,
          dateIso: new Date().toISOString(),
          config: sessionConfig,
          transcript: sessionTranscript,
          report: generatedReport,
          durationSeconds: sessionDuration,
        };
        setHistory(saveSession(saved));
      } catch (err) {
        setReportError(
          err instanceof Error ? err.message : 'Erreur lors de la génération du diagnostic.'
        );
      } finally {
        setReportLoading(false);
      }
    },
    []
  );

  const handleStartInterview = useCallback(
    (overrideConfig?: InterviewConfig) => {
      const targetConfig = overrideConfig ?? config;
      if (!targetConfig.role.trim() || !targetConfig.country.trim()) {
        setView('setup');
        return;
      }
      const frozenConfig: InterviewConfig = { ...targetConfig };
      setActiveSessionConfig(frozenConfig);
      setTranscript([]);
      setDurationSeconds(0);
      setReport(null);
      setReportError(null);
      setIsLiveActive(true);
      setView('live');
    },
    [config]
  );

  const handleFinishSession = useCallback(
    (finalTranscript: TranscriptEntry[], elapsedSeconds: number) => {
      setIsLiveActive(false);
      setTranscript(finalTranscript);
      setDurationSeconds(elapsedSeconds);
      setView('report');
      void generateDiagnostic(activeSessionConfig, finalTranscript, elapsedSeconds);
    },
    [activeSessionConfig, generateDiagnostic]
  );

  const handleTopBarPrimaryAction = () => {
    if (isLiveActive) {
      if (view === 'live') {
        handleFinishSession(transcript, durationSeconds);
      } else {
        setView('live');
      }
      return;
    }

    if (view === 'setup') {
      handleStartInterview();
    } else {
      setView('setup');
    }
  };

  const handleOpenSavedSession = (session: SavedSession) => {
    setActiveSessionConfig(session.config);
    setTranscript(session.transcript);
    setDurationSeconds(session.durationSeconds);
    setReport(session.report);
    setReportError(null);
    setReportLoading(false);
    setView('report');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <TopBar
        activeView={view}
        hasReport={Boolean(report || reportLoading || reportError)}
        historyCount={history.length}
        isLiveActive={isLiveActive}
        onNavigate={(nextView) => setView(nextView)}
        onPrimaryAction={handleTopBarPrimaryAction}
      />

      <div className="flex-1">
        {view === 'setup' && (
          <SetupWorkspace
            config={config}
            onChangeConfig={setConfig}
            onStartInterview={() => handleStartInterview()}
            onOpenStudio3D={() => setView('studio3d')}
          />
        )}

        {view === 'studio3d' && (
          <Studio3DView
            mode={config.mode}
            onChangeMode={(m) => setConfig((prev) => ({ ...prev, mode: m }))}
            onStartInterviewWith3D={() => {
              const nextConfig: InterviewConfig = { ...config, visualStyle: 'avatar_3d' };
              setConfig(nextConfig);
              handleStartInterview(nextConfig);
            }}
            onBackToSetup={() => setView('setup')}
          />
        )}

        {isLiveActive && (
          <div className={view === 'live' ? 'block' : 'hidden'}>
            <LiveCallView
              config={activeSessionConfig}
              transcript={transcript}
              onTranscriptChange={setTranscript}
              onUpdateVisualStyle={(style) => {
                setActiveSessionConfig((prev) => ({ ...prev, visualStyle: style }));
                setConfig((prev) => ({ ...prev, visualStyle: style }));
              }}
              onElapsedChange={setDurationSeconds}
              onFinishSession={handleFinishSession}
            />
          </div>
        )}

        {view === 'report' && (
          <DiagnosticReportView
            config={activeSessionConfig}
            transcript={transcript}
            durationSeconds={durationSeconds}
            report={report}
            loading={reportLoading}
            error={reportError}
            onRetry={() =>
              void generateDiagnostic(activeSessionConfig, transcript, durationSeconds)
            }
            onNewInterview={() => setView('setup')}
          />
        )}

        {view === 'history' && (
          <HistoryView
            sessions={history}
            onOpenSession={handleOpenSavedSession}
            onDeleteSession={(id) => setHistory(deleteSession(id))}
            onClearAll={() => setHistory(clearAllSessions())}
            onStartNew={() => setView('setup')}
          />
        )}
      </div>

      {view !== 'live' && view !== 'studio3d' && (
        <footer className="no-print border-t border-slate-200 bg-white py-5 text-center text-xs text-slate-500">
          Réussis ton Entretien International · Entraînement vocal &amp; bilan structuré en 5 axes
        </footer>
      )}
    </div>
  );
}
