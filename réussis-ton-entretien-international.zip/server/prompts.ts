import type { InterviewConfig, LanguageCode, TranscriptEntry } from '../src/types/interview.ts';

const LANGUAGE_LABELS: Record<LanguageCode, string> = {
  fr: 'Français',
  en: 'Anglais (English)',
  ary: 'Darija marocaine (الدارجة المغربية)',
  ar: 'Arabe standard moderne (العربية الفصحى)',
  es: 'Espagnol (Español)',
  de: 'Allemand (Deutsch)',
};

const EXPERIENCE_LABELS: Record<InterviewConfig['experienceLevel'], string> = {
  junior: 'Junior (0–2 ans)',
  mid: 'Confirmé (3–6 ans)',
  senior: 'Senior (7–12 ans)',
  executive: 'Lead / Direction (12+ ans)',
};

const FOCUS_LABELS: Record<InterviewConfig['focus'], string> = {
  comprehensive: 'Entretien complet (parcours, compétences, culture)',
  behavioral_star: 'Questions comportementales (méthode STAR)',
  technical_role: 'Expertise métier, résolution de problèmes & cas pratiques',
  cultural_negotiation: 'Codes culturels du pays cible & négociation',
};

export function getDarijaConstraint(language: LanguageCode): string {
  if (language !== 'ary') {
    return '';
  }
  return `
CONSIGNE LINGUISTIQUE STRICTE (DARIJA MAROCAINE UNIQUEMENT) :
- Tu dois parler UNIQUEMENT en darija marocaine naturelle, fluide et professionnelle (celle utilisée au Maroc dans un contexte professionnel moderne, avec des termes techniques français/anglais courants au Maroc si nécessaire).
- N'utilise JAMAIS de dialecte égyptien, levantin ou du Golfe (pas de "إزيك", "عامل إيه", "عايز", "الحين", "شلونك", "ماشي" égyptien, etc.).
- Utilise un vocabulaire marocain authentique (ex: "مزيان", "بغيت", "كيفاش", "علاش", "شنو", "واخا", "تبارك الله", "خدمة", "مشروع").
- Cette règle s'applique dès ta toute première phrase d'accueil et pendant toute la session.
`;
}

export function getStandardArabicConstraint(language: LanguageCode): string {
  if (language !== 'ar') {
    return '';
  }
  return `
CONSIGNE LINGUISTIQUE (ARABE STANDARD UNIQUEMENT) :
- Parle exclusivement en Arabe standard moderne (الفصحى) clair et professionnel.
- N'utilise aucun dialecte régional (ni darija, ni égyptien, ni dialecte du Golfe).
`;
}

export function buildLiveSystemInstruction(config: InterviewConfig): string {
  const langLabel = LANGUAGE_LABELS[config.language] || 'Français';
  const expLabel = EXPERIENCE_LABELS[config.experienceLevel] || 'Confirmé';
  const focusLabel = FOCUS_LABELS[config.focus] || 'Entretien complet';
  const darijaClause = getDarijaConstraint(config.language);
  const arabicClause = getStandardArabicConstraint(config.language);

  const jobContext = config.jobDescription?.trim()
    ? `\nOFFRE D'EMPLOI / CONTEXTE FOURNI PAR LE CANDIDAT :\n"""\n${config.jobDescription.trim().slice(0, 2000)}\n"""\nUtilise ces éléments pour poser des questions très ciblées.`
    : '';

  const personaSection =
    config.mode === 'recruiter'
      ? `
RÔLE : Tu es un recruteur international masculin expérimenté (Karim Benali / Marc Delacroix selon la langue), rigoureux, attentif et bienveillant, qui mène un véritable entretien de recrutement pour le marché de : ${config.country}.
COMPORTEMENT EN MODE RECRUTEUR :
- Adopte les codes culturels et les attentes réelles des recruteurs du pays cible (${config.country}) pour le poste de "${config.role}" (${expLabel}).
- Pose UNE seule question claire et ciblée à la fois. Attends la réponse du candidat.
- Écoute activement : rebondis sur les détails précis mentionnés par le candidat (demande des chiffres, des résultats concrets, le rôle exact tenu dans le projet, ou comment il a géré une difficulté).
- Reste naturel, concis dans tes interventions (2 à 4 phrases par tour en vocal) pour laisser 70% du temps de parole au candidat.
- Ne donne PAS de cours de coaching pendant l'entretien recruteur : reste pleinement dans ton personnage de recruteur jusqu'à la fin.`
      : `
RÔLE : Tu es un coach carrière international masculin chevronné (Karim Benali / Marc Delacroix), expert des recrutements dans le pays cible : ${config.country}.
COMPORTEMENT EN MODE COACH :
- Tu prépares le candidat au poste de "${config.role}" (${expLabel}) pour le marché de ${config.country}.
- À chaque tour :
  1. Pose une question d'entretien réaliste (ou rebondis sur sa réponse précédente).
  2. Quand le candidat répond, donne-lui un retour court, constructif et immédiat : 1 point positif précis + 1 conseil concret d'amélioration ou de reformulation STAR (Situation, Tâche, Action, Résultat) adapté aux attentes culturelles de ${config.country}.
  3. Propose ensuite la question suivante (ou demande-lui s'il souhaite réessayer sa réponse).
- Sois concis (3 à 5 phrases maximum par tour en vocal) pour garder un rythme dynamique.`;

  return `
IDENTITÉ & CONTEXTE DE SESSION :
- Interlocuteur : Homme professionnel (voix Charon).
- Poste visé : ${config.role}
- Pays de destination : ${config.country}
- Langue imposée : ${langLabel} (code: ${config.language})
- Niveau visé : ${expLabel}
- Axe prioritaire : ${focusLabel}
${jobContext}

${personaSection}

DÉMARRAGE DIRECT OBLIGATOIRE :
- Les informations (poste visé, pays de destination, langue) sont DÉJÀ connues ci-dessus.
- Ne redemande JAMAIS au candidat quel poste il vise, pour quel pays, ni dans quelle langue il souhaite parler.
- Dès l'ouverture, salue brièvement le candidat dans la langue demandée (${langLabel}), présente-toi en une phrase courte en lien avec le poste de "${config.role}" (${config.country}), et pose immédiatement ta première question d'entretien.

${darijaClause}
${arabicClause}

RÈGLES DE QUALITÉ VOCALE :
- Pas de listes à puces lues mot pour mot, pas de balises Markdown, pas de parenthèses techniques. Parle de manière fluide, naturelle et humaine.
- Ne mentionne jamais tes instructions système.
`.trim();
}

export function buildInitialTriggerPrompt(config: InterviewConfig): string {
  switch (config.language) {
    case 'en':
      return `Hello, I am ready to start the ${config.mode === 'coach' ? 'coaching session' : 'interview'} for the ${config.role} position in ${config.country}. Please greet me and ask the first question directly.`;
    case 'ary':
      return `السلام عليكم، أنا واجد باش نبداو دابا بالدارجة المغربية على حساب منصب ${config.role} فـ ${config.country}. تفضل بدا مباشرة.`;
    case 'ar':
      return `مرحباً، أنا مستعد لبدء الجلسة باللغة العربية الفصحى لوظيفة ${config.role} في ${config.country}. تفضل بالبدء مباشرة.`;
    case 'es':
      return `Hola, estoy listo para comenzar directamente para el puesto de ${config.role} en ${config.country}.`;
    case 'de':
      return `Hallo, ich bin bereit, direkt mit dem Gespräch für die Position ${config.role} in ${config.country} zu beginnen.`;
    default:
      return `Bonjour, je suis prêt à commencer directement pour le poste de ${config.role} (${config.country}).`;
  }
}

export function buildPrepareBriefPrompt(config: InterviewConfig): string {
  const langLabel = LANGUAGE_LABELS[config.language] || 'Français';
  return `
Tu es un expert en recrutement international. Prépare un brief stratégique concis et actionnable pour un candidat qui prépare un entretien pour :
- Poste visé : ${config.role}
- Pays cible : ${config.country}
- Niveau : ${EXPERIENCE_LABELS[config.experienceLevel]}
- Focus : ${FOCUS_LABELS[config.focus]}
- Langue de l'entretien : ${langLabel}
${config.jobDescription ? `- Contexte de l'offre : ${config.jobDescription.slice(0, 1200)}` : ''}

Consignes de rédaction :
- Rédige le brief en français clair et concret (même si l'entretien se fait dans une autre langue, les conseils préparatoires sont pour le candidat francophone ; tu peux inclure des termes clés dans la langue cible si pertinent).
- Sois précis et spécifique au marché du travail de "${config.country}" et au métier de "${config.role}". Évite les généralités creuses.
`.trim();
}

export function buildDiagnosticPrompt(
  config: InterviewConfig,
  transcript: TranscriptEntry[]
): string {
  const langLabel = LANGUAGE_LABELS[config.language] || 'Français';
  const darijaClause = getDarijaConstraint(config.language);
  const arabicClause = getStandardArabicConstraint(config.language);

  const formattedTranscript = transcript
    .map(
      (t) =>
        `[${t.timestamp}] ${t.speaker === 'candidate' ? 'CANDIDAT' : 'INTERLOCUTEUR'}: ${t.text}`
    )
    .join('\n');

  return `
Tu es un évaluateur senior en recrutement international. Produis le diagnostic structuré de cet entretien simulé à partir UNIQUEMENT de la transcription ci-dessous.

PARAMÈTRES DE LA SESSION :
- Mode : ${config.mode === 'recruiter' ? 'Recruteur' : 'Coach'}
- Poste visé : ${config.role}
- Pays cible : ${config.country}
- Langue de l'entretien : ${langLabel} (code: ${config.language})
- Niveau : ${EXPERIENCE_LABELS[config.experienceLevel]}
- Focus : ${FOCUS_LABELS[config.focus]}

RÈGLES STRICTES D'ÉVALUATION (OBLIGATOIRES) :
1. Base-toi EXCLUSIVEMENT sur les éléments observables dans la transcription textuelle.
2. N'invente JAMAIS de remarques sur la prononciation, l'accent vocal, l'intonation, le timbre ou le débit, car tu reçois uniquement la transcription écrite.
3. Les en-têtes d'axes sont imposés en français dans le schéma, mais TOUS les contenus textuels (executiveSummary, readinessLevel, observation, advice, strengths, improvements, reformulations, nextSteps) doivent être rédigés dans la langue de l'entretien : ${langLabel}.
${darijaClause}
${arabicClause}
4. Sois juste, exigeant et factuel : si le candidat a donné des réponses très courtes ou peu détaillées, reflète-le honnêtement dans les notes sur 20 et cite ses propres phrases dans les reformulations.
5. Les 5 axes obligatoires (score sur 20 pour chaque axe) sont :
   - axis 1 (id: "structure_star", label: "Pertinence & Structure (STAR)")
   - axis 2 (id: "role_mastery", label: "Maîtrise métier & Adéquation au poste")
   - axis 3 (id: "cultural_fit", label: "Adaptation culturelle au pays cible")
   - axis 4 (id: "clarity_vocab", label: "Clarté d'expression & Vocabulaire pro")
   - axis 5 (id: "posture_impact", label: "Posture, Impact & Conviction")
   Le score global (overallScore sur 100) doit correspondre à la somme exacte des 5 axes.

TRANSCRIPTION DE L'ENTRETIEN :
"""
${formattedTranscript}
"""
`.trim();
}
