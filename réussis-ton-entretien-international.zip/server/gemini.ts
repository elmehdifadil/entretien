import { GoogleGenAI, ThinkingLevel, type GenerateContentParameters } from '@google/genai';

const clientCache = new Map<string, GoogleGenAI>();

export function getAiClient(apiVersion?: string): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY est manquante. Veuillez la configurer dans le panneau Settings > Secrets.'
    );
  }

  const cacheKey = `${apiKey}:${apiVersion || 'default'}`;
  const existing = clientCache.get(cacheKey);
  if (existing) {
    return existing;
  }

  const client = new GoogleGenAI({
    apiKey,
    ...(apiVersion ? { apiVersion } : {}),
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
  clientCache.set(cacheKey, client);
  return client;
}

export async function withRetry<T>(fn: () => Promise<T>, maxAttempts = 2): Promise<T> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      const message = err instanceof Error ? err.message : String(err);
      const isRetryable =
        message.includes('429') ||
        message.includes('503') ||
        message.includes('500') ||
        message.toLowerCase().includes('unavailable') ||
        message.toLowerCase().includes('timeout');

      if (!isRetryable || attempt === maxAttempts) {
        throw err;
      }
      await new Promise((resolve) => setTimeout(resolve, 450 * attempt));
    }
  }
  throw lastError;
}

export async function generateWithFallback(
  ai: GoogleGenAI,
  params: Omit<GenerateContentParameters, 'model'> & {
    primaryModel?: string;
    fallbackModel?: string;
  }
) {
  const primary = params.primaryModel || 'gemini-4-hydrogen';
  const fallback = params.fallbackModel || 'gemini-3.1-flash-lite';

  const { primaryModel: _p, fallbackModel: _f, ...rest } = params;

  try {
    return await withRetry(
      () =>
        ai.models.generateContent({
          ...rest,
          model: primary,
        }),
      2
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const shouldFallback =
      primary !== fallback &&
      (msg.includes('503') ||
        msg.includes('429') ||
        msg.includes('404') ||
        msg.includes('UNAVAILABLE') ||
        msg.includes('high demand'));

    if (!shouldFallback) {
      throw err;
    }

    console.warn(`Primary model ${primary} unavailable (${msg}), falling back to ${fallback}`);
    const fallbackConfig = { ...(rest.config || {}) };
    if (fallback === 'gemini-3.1-flash-lite' && fallbackConfig.thinkingConfig) {
      fallbackConfig.thinkingConfig = { thinkingLevel: ThinkingLevel.MINIMAL };
    }

    return await withRetry(
      () =>
        ai.models.generateContent({
          ...rest,
          config: fallbackConfig,
          model: fallback,
        }),
      2
    );
  }
}

export function formatGeminiError(err: unknown): { status: number; message: string } {
  const raw = err instanceof Error ? err.message : String(err);
  if (raw.includes('GEMINI_API_KEY')) {
    return { status: 500, message: raw };
  }
  if (raw.includes('403') || raw.includes('PERMISSION_DENIED')) {
    return {
      status: 403,
      message:
        'Clé API refusée ou invalide (403). Vérifiez votre clé dans le panneau Settings > Secrets.',
    };
  }
  if (raw.includes('429') || raw.includes('RESOURCE_EXHAUSTED')) {
    return {
      status: 429,
      message:
        'Quota Gemini temporairement atteint (429). Patientez quelques instants avant de réessayer.',
    };
  }
  if (raw.includes('503') || raw.includes('UNAVAILABLE')) {
    return {
      status: 503,
      message:
        'Le service Gemini connaît un pic de trafic temporaire (503). Veuillez réessayer dans quelques secondes.',
    };
  }
  if (raw.includes('404') || raw.includes('NOT_FOUND')) {
    return {
      status: 404,
      message: 'Modèle Gemini introuvable (404). Vérifiez la configuration serveur.',
    };
  }
  return {
    status: 500,
    message: raw || 'Une erreur inattendue est survenue avec le service Gemini.',
  };
}
