import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import { Modality, ThinkingLevel, Type, type LiveServerMessage } from '@google/genai';
import {
  formatGeminiError,
  generateWithFallback,
  getAiClient,
  withRetry,
} from './server/gemini.ts';
import {
  buildDiagnosticPrompt,
  buildInitialTriggerPrompt,
  buildLiveSystemInstruction,
  buildPrepareBriefPrompt,
} from './server/prompts.ts';
import type { InterviewConfig, TranscriptEntry } from './src/types/interview.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);

const app = express();
app.use(express.json({ limit: '8mb' }));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, hasApiKey: Boolean(process.env.GEMINI_API_KEY?.trim()) });
});

app.post('/api/interview/prepare', async (req, res) => {
  try {
    const config = req.body?.config as InterviewConfig | undefined;
    if (!config?.role?.trim() || !config?.country?.trim()) {
      res.status(400).json({ error: 'Le poste visé et le pays de destination sont requis.' });
      return;
    }

    const ai = getAiClient();
    const response = await generateWithFallback(ai, {
      primaryModel: 'gemini-4-hydrogen',
      fallbackModel: 'gemini-3.1-flash-lite',
      contents: buildPrepareBriefPrompt(config),
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            culturalCodes: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 attentes culturelles précises des recruteurs dans ce pays.',
            },
            expectedThemes: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 compétences ou questions clés probables pour ce poste.',
            },
            smartQuestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '2 questions pertinentes que le candidat peut poser en fin d’entretien.',
            },
            openingTip: {
              type: Type.STRING,
              description: '1 conseil concret pour réussir les 60 premières secondes.',
            },
          },
          required: ['culturalCodes', 'expectedThemes', 'smartQuestions', 'openingTip'],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim());
    res.json({ brief: parsed });
  } catch (err) {
    const { status, message } = formatGeminiError(err);
    res.status(status).json({ error: message });
  }
});

app.post('/api/transcribe', async (req, res) => {
  try {
    const { audioBase64, mimeType, language } = req.body as {
      audioBase64?: string;
      mimeType?: string;
      language?: string;
    };
    if (!audioBase64) {
      res.status(400).json({ error: 'Audio manquant pour la transcription.' });
      return;
    }

    const ai = getAiClient();
    const response = await withRetry(() =>
      ai.models.generateContent({
        model: 'gemini-3.5-transcribe',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: mimeType || 'audio/webm',
                data: audioBase64,
              },
            },
            {
              text: `Transcribe accurately the spoken words in this audio (expected language code: ${
                language || 'fr'
              }). Return only the transcribed speech without commentary.`,
            },
          ],
        },
      })
    );

    res.json({ text: (response.text ?? '').trim() });
  } catch (err) {
    const { status, message } = formatGeminiError(err);
    res.status(status).json({ error: message });
  }
});

app.post('/api/interview/turn', async (req, res) => {
  try {
    const { config, history, candidateMessage, withAudio } = req.body as {
      config?: InterviewConfig;
      history?: Array<{ speaker: 'candidate' | 'interviewer'; text: string }>;
      candidateMessage?: string;
      withAudio?: boolean;
    };

    if (!config?.role?.trim() || !config?.country?.trim()) {
      res.status(400).json({ error: 'Configuration d’entretien invalide.' });
      return;
    }

    const ai = getAiClient();
    const systemInstruction = buildLiveSystemInstruction(config);

    const contents =
      history && history.length > 0
        ? [
            ...history.map((item) => ({
              role: item.speaker === 'candidate' ? ('user' as const) : ('model' as const),
              parts: [{ text: item.text }],
            })),
            ...(candidateMessage?.trim()
              ? [{ role: 'user' as const, parts: [{ text: candidateMessage.trim() }] }]
              : []),
          ]
        : [
            {
              role: 'user' as const,
              parts: [{ text: candidateMessage?.trim() || buildInitialTriggerPrompt(config) }],
            },
          ];

    const textResponse = await generateWithFallback(ai, {
      primaryModel: 'gemini-4-hydrogen',
      fallbackModel: 'gemini-3.1-flash-lite',
      contents,
      config: {
        systemInstruction,
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      },
    });

    const replyText = (textResponse.text ?? '').trim();
    if (!replyText) {
      res.status(502).json({ error: 'Réponse vide reçue du modèle.' });
      return;
    }

    let audioBase64Wav: string | undefined;
    if (withAudio) {
      try {
        const ttsAi = getAiClient('v1beta');
        const ttsResponse = await ttsAi.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [
            {
              role: 'user',
              parts: [
                {
                  text: replyText,
                  speechMetadata: {
                    style:
                      config.mode === 'recruiter'
                        ? 'Calm, articulate international executive recruiter, natural pace'
                        : 'Warm, encouraging senior career coach, clear pacing',
                  },
                },
              ],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: 'Charon' },
              },
            },
          },
        });
        audioBase64Wav = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      } catch (ttsErr) {
        console.warn('TTS generation skipped in turn:', ttsErr);
      }
    }

    res.json({ replyText, audioBase64Wav });
  } catch (err) {
    const { status, message } = formatGeminiError(err);
    res.status(status).json({ error: message });
  }
});

app.post('/api/report', async (req, res) => {
  try {
    const { config, transcript } = req.body as {
      config?: InterviewConfig;
      transcript?: TranscriptEntry[];
    };

    if (!config?.role?.trim() || !config?.country?.trim()) {
      res.status(400).json({ error: 'Configuration de session manquante pour le diagnostic.' });
      return;
    }

    const candidateTurns = (transcript ?? []).filter(
      (t) => t.speaker === 'candidate' && t.text.trim().length > 0
    );

    if (candidateTurns.length === 0) {
      res.status(400).json({
        error:
          "Aucune réponse du candidat n'a été transcrite durant la session. Le diagnostic nécessite au moins une prise de parole.",
      });
      return;
    }

    const ai = getAiClient('v1beta');
    const reportModel = process.env.GEMINI_REPORT_MODEL?.trim() || 'gemini-4-hydrogen';

    const response = await generateWithFallback(ai, {
      primaryModel: reportModel,
      fallbackModel: 'gemini-3.1-flash-lite',
      contents: buildDiagnosticPrompt(config, transcript ?? []),
      config: {
        ...(reportModel === 'gemini-3.1-flash-lite'
          ? { thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL } }
          : { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }),
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overallScore: { type: Type.INTEGER, description: 'Score total sur 100.' },
            readinessLevel: {
              type: Type.STRING,
              description:
                'Niveau de préparation synthétique (ex: Prêt, Solide à affiner, En progression).',
            },
            executiveSummary: {
              type: Type.STRING,
              description: 'Synthèse globale objective basée uniquement sur la transcription.',
            },
            axes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  label: { type: Type.STRING },
                  score: { type: Type.INTEGER, description: 'Note entre 0 et 20.' },
                  maxScore: { type: Type.INTEGER, description: 'Toujours 20.' },
                  observation: { type: Type.STRING },
                  advice: { type: Type.STRING },
                },
                required: ['id', 'label', 'score', 'maxScore', 'observation', 'advice'],
              },
            },
            strengths: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            improvements: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            reformulations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  original: { type: Type.STRING },
                  improved: { type: Type.STRING },
                  rationale: { type: Type.STRING },
                },
                required: ['original', 'improved', 'rationale'],
              },
            },
            nextSteps: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: [
            'overallScore',
            'readinessLevel',
            'executiveSummary',
            'axes',
            'strengths',
            'improvements',
            'reformulations',
            'nextSteps',
          ],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim());
    if (Array.isArray(parsed.axes)) {
      parsed.axes = parsed.axes.map((a: Record<string, unknown>) => ({
        ...a,
        maxScore: 20,
        score: Math.max(0, Math.min(20, Number(a.score) || 0)),
      }));
      const sum = parsed.axes.reduce(
        (acc: number, item: { score: number }) => acc + item.score,
        0
      );
      parsed.overallScore = sum;
    }

    res.json({
      report: {
        ...parsed,
        generatedAt: new Date().toISOString(),
        language: config.language,
      },
    });
  } catch (err) {
    const { status, message } = formatGeminiError(err);
    res.status(status).json({ error: message });
  }
});

app.post('/api/tts', async (req, res) => {
  try {
    const { text } = req.body as { text?: string };
    if (!text?.trim()) {
      res.status(400).json({ error: 'Texte manquant pour la lecture vocale.' });
      return;
    }

    const ai = getAiClient('v1beta');
    const ttsResponse = await withRetry(() =>
      ai.models.generateContent({
        model: 'gemini-3.8-flash-lite-tts',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: text.slice(0, 3500),
                speechMetadata: {
                  style: 'Clear, calm executive career advisor reading a structured evaluation',
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Charon' },
            },
          },
        },
      })
    );

    const audioBase64Wav = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!audioBase64Wav) {
      res.status(502).json({ error: 'Audio TTS indisponible.' });
      return;
    }

    res.json({ audioBase64Wav });
  } catch (err) {
    const { status, message } = formatGeminiError(err);
    res.status(status).json({ error: message });
  }
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws/live' });

wss.on('connection', (clientWs: WebSocket) => {
  let liveSession: Awaited<ReturnType<ReturnType<typeof getAiClient>['live']['connect']>> | null =
    null;
  let closed = false;

  const safeSend = (payload: Record<string, unknown>) => {
    if (clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(JSON.stringify(payload));
    }
  };

  const connectLive = async (
    config: InterviewConfig,
    apiVersion: string,
    allowRetryAlpha: boolean
  ): Promise<void> => {
    const ai = getAiClient(apiVersion);
    const systemInstruction = buildLiveSystemInstruction(config);
    let opened = false;

    liveSession = await ai.live.connect({
      model: process.env.GEMINI_LIVE_MODEL?.trim() || 'gemini-3.8-live',
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Charon' },
          },
        },
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        systemInstruction,
      },
      callbacks: {
        onopen: () => {
          opened = true;
          safeSend({ type: 'ready' });
        },
        onmessage: (message: LiveServerMessage) => {
          const serverContent = message.serverContent;
          if (!serverContent) return;

          if (serverContent.inputTranscription?.text) {
            safeSend({
              type: 'input_transcript',
              text: serverContent.inputTranscription.text,
            });
          }

          if (serverContent.outputTranscription?.text) {
            safeSend({
              type: 'output_transcript',
              text: serverContent.outputTranscription.text,
            });
          }

          for (const part of serverContent.modelTurn?.parts ?? []) {
            if (part.inlineData?.data) {
              safeSend({ type: 'audio', audio: part.inlineData.data });
            }
          }

          if (serverContent.interrupted) {
            safeSend({ type: 'interrupted' });
          }

          if (serverContent.turnComplete) {
            safeSend({ type: 'turn_complete' });
          }
        },
        onerror: (e: unknown) => {
          const maybeErr = e as { message?: string; error?: { message?: string } };
          const errMsg =
            e instanceof Error
              ? e.message
              : maybeErr?.error?.message || maybeErr?.message || 'Erreur de connexion Gemini Live.';
          console.error(`Gemini Live (${apiVersion}) onerror:`, errMsg);

          if (!opened && allowRetryAlpha && errMsg.includes('404')) {
            void connectLive(config, 'v1alpha', false).catch((err2) => {
              safeSend({
                type: 'live_unavailable',
                message: err2 instanceof Error ? err2.message : errMsg,
              });
            });
            return;
          }

          if (!opened) {
            safeSend({ type: 'live_unavailable', message: errMsg });
          } else {
            safeSend({ type: 'error', message: errMsg });
          }
        },
        onclose: () => {
          if (!closed && opened) {
            safeSend({ type: 'closed' });
          }
        },
      },
    });

    if (liveSession) {
      liveSession.sendClientContent({
        turns: [
          {
            role: 'user',
            parts: [{ text: buildInitialTriggerPrompt(config) }],
          },
        ],
        turnComplete: true,
      });
    }
  };

  clientWs.on('message', async (rawData) => {
    try {
      const msg = JSON.parse(rawData.toString()) as {
        type: string;
        config?: InterviewConfig;
        audio?: string;
        text?: string;
      };

      if (msg.type === 'start' && msg.config) {
        const config = msg.config;
        if (!config.role?.trim() || !config.country?.trim()) {
          safeSend({ type: 'error', message: 'Poste et pays requis pour démarrer.' });
          return;
        }
        await connectLive(config, 'v1beta', true);
      } else if (msg.type === 'audio' && msg.audio && liveSession) {
        liveSession.sendRealtimeInput({
          audio: {
            data: msg.audio,
            mimeType: 'audio/pcm;rate=16000',
          },
        });
      } else if (msg.type === 'text' && msg.text && liveSession) {
        liveSession.sendClientContent({
          turns: [
            {
              role: 'user',
              parts: [{ text: msg.text }],
            },
          ],
          turnComplete: true,
        });
      } else if (msg.type === 'stop') {
        closed = true;
        if (liveSession) {
          liveSession.close();
          liveSession = null;
        }
      }
    } catch (err) {
      const { message } = formatGeminiError(err);
      safeSend({ type: 'live_unavailable', message });
    }
  });

  clientWs.on('close', () => {
    closed = true;
    if (liveSession) {
      try {
        liveSession.close();
      } catch {
        // ignore close errors
      }
      liveSession = null;
    }
  });
});

async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Entretien International server listening on http://0.0.0.0:${PORT}`);
  });
}

start().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
